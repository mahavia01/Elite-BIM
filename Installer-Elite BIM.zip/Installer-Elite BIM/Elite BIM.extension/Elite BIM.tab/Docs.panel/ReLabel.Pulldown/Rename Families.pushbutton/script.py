import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitServices")
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
from pyrevit import revit, forms, script
from rpw.ui.forms import FlexForm, TextBox, Button, Label
from Autodesk.Revit.DB import *



doc = revit.doc
uidoc = revit.uidoc

families = FilteredElementCollector(doc)\
                .OfClass(Family)\
                .ToElements()

components = [
    Label('Enter Suffix Or Prefix To Rename Families:'),
    TextBox('Prefix', Text='Enter Prefix Here'),
    TextBox('Suffix', Text='Enter Suffix Here'),
    Button('OK')
]

form = FlexForm('Rename Families', components)
form.show()

if form.values:
    entered_prefix = form.values['Prefix']
    entered_suffix = form.values['Suffix']

    if entered_prefix == 'Enter Prefix Here':
        entered_prefix = ''
    
    if entered_suffix == 'Enter Suffix Here':
        entered_suffix = ''

    if not entered_prefix and not entered_suffix:
        forms.alert("No valid prefix or suffix provided\nExiting")
        script.exit()
else:
    forms.alert("No Input Provided\nExiting")
    script.exit()

with Transaction(doc, "Rename Families") as t:
    t.Start()
    
    renamed_families = []
    for fam in families:
        if fam.IsValidObject:
            try:
                old_name = fam.Name
                new_name = entered_prefix + old_name + entered_suffix
                fam.Name = new_name
                renamed_families.append((old_name, new_name))
            except Exception as e:
                print("Failed to rename family {}: {}".format(fam.Name, str(e)))
    
    t.Commit()

Dialog = TaskDialog("Operation Complete")
Dialog.MainInstruction = "All Loadable Families Are Renamed"
Dialog.MainContent = "Thanks For Using Elite-BIM | Aurthor : Muhammad Mahavia"
Dialog.Show()