import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitServices")
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
from pyrevit import revit, forms, script
from rpw.ui.forms import FlexForm, TextBox, Button, Label
from Autodesk.Revit.DB import *

doc = revit.doc
uidoc = revit.uidoc

families = FilteredElementCollector(doc).OfClass(Family).ToElements()

components = [
    Label('Bulk Family Name Replacement:'),
    Label('Enter text to find and replace in family names'),
    TextBox('Find', Text='Text to find'),
    TextBox('Replace', Text='Replacement text'),
    Button('OK')
]

form = FlexForm('Rename Families', components)
form.show()

if form.values:
    search_text = form.values['Find']
    replace_text = form.values['Replace']
    
    if search_text == 'Text to find':
        search_text = ''
    if replace_text == 'Replacement text':
        replace_text = ''
    
    if not search_text:
        forms.alert("No search text provided. Please enter text to find.", exitscript=True)
    
else:
    forms.alert("No input provided. Operation cancelled.", exitscript=True)

with Transaction(doc, "Rename Families with Text Replacement") as t:
    t.Start()
    
    renamed_families = []
    skipped_families = []
    
    for fam in families:
        if fam.IsValidObject:
            try:
                old_name = fam.Name
                if search_text in old_name:
                    new_name = old_name.Replace(search_text, replace_text)
                    if new_name != old_name:
                        fam.Name = new_name
                        renamed_families.append((old_name, new_name))
                else:
                    skipped_families.append(old_name)
                    
            except Exception as e:
                print("Failed to rename family {}: {}".format(fam.Name, str(e)))
                skipped_families.append(old_name)
    
    t.Commit()

if renamed_families:
    result_message = "Successfully renamed {} families:\n\n".format(len(renamed_families))
    for i, (old_name, new_name) in enumerate(renamed_families[:10]):
        result_message += " {} > {}\n".format(old_name, new_name)
    if len(renamed_families) > 10:
        result_message += "\n... and {} more families.".format(len(renamed_families) - 10)
    if skipped_families:
        result_message += "\n\nSkipped {} families (text not found or error):".format(len(skipped_families))
        result_message += "\n" + ", ".join(skipped_families[:5])
        if len(skipped_families) > 5:
            result_message += ", ..." 
else:
    result_message = "No families were renamed.\n"
    result_message += "The text '{}' was not found in any family names.".format(search_text)
    if skipped_families:
        result_message += "\n\nChecked {} families.".format(len(skipped_families))

# Show results
Dialog = TaskDialog("Family Renaming Operation Complete")
Dialog.MainInstruction = "Family Name Replacement Results"
Dialog.MainContent = result_message
Dialog.FooterText = "Tool Created By Muhammad Mahavia | Elite-BIM"
Dialog.Show()