from pyrevit import revit, forms, script
from Autodesk.Revit.DB import FilteredElementCollector, ViewSheet, ViewFamilyType, Transaction, ElementId, BuiltInCategory
import clr
import sys

# Add reference to Microsoft.Office.Interop.Excel
try:
    clr.AddReference('Microsoft.Office.Interop.Excel')
    from Microsoft.Office.Interop import Excel
except:
    forms.alert("Microsoft.Office.Interop.Excel not available. Trying alternative methods...")

doc = revit.doc
uidoc = revit.uidoc

if not doc:
    forms.alert("No Revit document is open. Please open a project first.", title="Error")
    script.exit()

excel_path = forms.pick_file(file_ext='xlsx', title='Select Excel File with Sheet Info')
if not excel_path:
    forms.alert("No file selected. Exiting.")
    script.exit()

sheet_data = []

try:
    # Method 1: Try using Microsoft.Office.Interop.Excel
    try:
        excel_app = Excel.ApplicationClass()
        workbook = excel_app.Workbooks.Open(excel_path)
        sheet = workbook.Sheets.Item[1]
        row = 2
        sheet_number_col = 1  # Column A
        sheet_name_col = 2    # Column B
        
        while True:
            number_cell = sheet.Cells(row, sheet_number_col)
            name_cell = sheet.Cells(row, sheet_name_col)
            
            if number_cell.Value2 is None or name_cell.Value2 is None:
                break
                
            sheet_data.append((str(number_cell.Value2), str(name_cell.Value2)))
            row += 1
        
        workbook.Close(False)
        excel_app.Quit()
        
    except:
        # Method 2: Fallback to pandas if Office Interop fails
        try:
            import pandas as pd
            df = pd.read_excel(excel_path, header=0)
            
            for _, row in df.iterrows():
                if pd.notna(row.iloc[0]) and pd.notna(row.iloc[1]):
                    sheet_data.append((str(row.iloc[0]), str(row.iloc[1])))
                    
        except ImportError:
            # Method 3: Fallback to openpyxl if pandas is not available
            try:
                import openpyxl
                workbook = openpyxl.load_workbook(excel_path)
                sheet = workbook.active
                
                for row in sheet.iter_rows(min_row=2, values_only=True):
                    if row[0] is not None and row[1] is not None:
                        sheet_data.append((str(row[0]), str(row[1])))
                        
            except Exception as e:
                forms.alert("All Excel reading methods failed: {}".format(str(e)))
                script.exit()

except Exception as e:
    forms.alert("Failed to read Excel file: {}".format(str(e)))
    script.exit()

# Create sheets in Revit
if not sheet_data:
    forms.alert("No sheet data found in Excel file.")
    script.exit()

view_family_types = FilteredElementCollector(doc).OfClass(ViewFamilyType).ToElements()
if not view_family_types:
    forms.alert("No view family types found in the document.")
    script.exit()

view_family_type = view_family_types[0]  # Pick the first one
created_count = 0

t = Transaction(doc, "Create Sheets from Excel")
t.Start()

for number, name in sheet_data:
    try:
        new_sheet = ViewSheet.CreatePlaceholder(doc)
        new_sheet.SheetNumber = number
        new_sheet.Name = name
        created_count += 1
    except Exception as e:
        print("Failed to create sheet {}: {}".format(number, str(e)))
        continue

t.Commit()

forms.alert("Created {} sheets from Excel.".format(created_count), title="Success")