# This script is created and managed by Malik Mahavia
# For any help or support, Contact: m.mahavia01@gmail.com


import os
import csv
from Autodesk.Revit.DB import TextNote
from Autodesk.Revit.UI import TaskDialog
from Autodesk.Revit.UI.Selection import ObjectType
from pyrevit import forms, script


uidoc = __revit__.ActiveUIDocument
doc = uidoc.Document


forms.alert("Select the text notes you want to export to CSV.", title="Export Text Notes", warn_icon=False)
selection = uidoc.Selection
try:
    picked_refs = selection.PickObjects(ObjectType.Element, "Select Text Notes to Export")
except:
    TaskDialog.Show("Cancelled", "No Texts selected.")
    script.exit()


data = []
for ref in picked_refs:
    el = doc.GetElement(ref.ElementId)
    if isinstance(el, TextNote):
        view_name = doc.GetElement(el.OwnerViewId).Name
        text_value = el.Text
        data.append((view_name, text_value))

if not data:
    TaskDialog.Show("No Text Notes", "No text notes found in your selection.")
    script.exit()


desktop = os.path.join(os.path.expanduser("~"), "Desktop")
file_path = os.path.join(desktop, "Malik Mahavia (Text Data Export To Excel).csv")


with open(file_path, "wb") as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(["View Name", "Text Content"])
    for row in data:
        safe_row = [str(item).encode('utf-8') for item in row]
        writer.writerow(safe_row)

TaskDialog.Show("Success", "Exported {} text notes to:\n{}".format(len(data), file_path))