from Autodesk.Revit.DB import FilteredElementCollector, ImportInstance, Transaction
from Autodesk.Revit.UI import TaskDialog, TaskDialogCommonButtons, TaskDialogResult
from pyrevit import revit, forms, script

doc = revit.doc




All_CADs = FilteredElementCollector(doc).OfClass(ImportInstance).ToElements()




Button = TaskDialog.Show("Massage", "Do you want to delete all CAD files from the model? Select 'No' to pin them instead.", TaskDialogCommonButtons.Yes | TaskDialogCommonButtons.No)
if not All_CADs:
    forms.alert("No CAD Files Available In Current Model")
    script.exit()
    if Button == TaskDialogResult.Yes:
        t = Transaction(doc, "Delete all CAD")
        t.Start()
        for cad in All_CADs:
            doc.Delete(cad.Id)
        t.Commit()
        TaskDialog.Show("CAD Manager (Mahavia)", "Done! All CAD Files has been remove form model")

    elif Button == TaskDialogResult.No:
        t = Transaction(doc, "Pin All CAD")
        t.Start()
        for cad in All_CADs:
            cad.Pinned = True
        t.Commit()
        TaskDialog.Show("CAD Manager (Mahavia)", "Done! All CAD Files has been Pinned Seccessfully")


        

  

