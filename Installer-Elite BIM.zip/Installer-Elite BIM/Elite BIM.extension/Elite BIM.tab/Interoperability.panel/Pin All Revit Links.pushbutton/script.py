from Autodesk.Revit.DB import FilteredElementCollector, BuiltInCategory, Transaction, Level, RevitLinkInstance
from Autodesk.Revit.UI import TaskDialog 
from pyrevit import revit


doc = revit.doc




All_Grids = FilteredElementCollector(doc)\
    .OfCategory(BuiltInCategory.OST_Grids)\
    .WhereElementIsNotElementType()\
    .ToElements()
All_Levels = FilteredElementCollector(doc).OfClass(Level).ToElements()

All_Revit_Links = FilteredElementCollector(doc).OfClass(RevitLinkInstance).ToElements()






All_Grids_List = []
All_Levels_List = []


# if not All_Grids_List and not All_Levels_List:
#     TaskDialog.Show("Element Pinned Status (By Mahavia)", "No Level & Grids Found in The Project")


T = Transaction(doc, "To Pin Elements")
T.Start()
        
for grids in All_Grids:
    if not grids.Pinned:
        All_Grids_List.append(grids)
    for grid in All_Grids_List:
        grid.Pinned = True


for levels in All_Levels:
    if not levels.Pinned:
        All_Levels_List.append(levels)
    for level in All_Levels_List:
        level.Pinned = True

for links in All_Revit_Links:
    links.Pinned = True

TaskDialog.Show("Element Pinned Status (By Mahavia)", "**All Grids, Levels, and Revit Links have been pinned successfully.**")




T.Commit()


