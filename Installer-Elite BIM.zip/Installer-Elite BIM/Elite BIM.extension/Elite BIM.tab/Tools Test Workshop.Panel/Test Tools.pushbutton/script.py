# -------------------------------
# Builder's Work Opening Tool
# Author: Muhammad Mahavia
# Contact: m.mahavia01@gmail.com
# -------------------------------

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitServices")
clr.AddReference("System")

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
from System.Collections.Generic import List

from pyrevit import forms, revit

doc = revit.doc
uidoc = revit.uidoc

# -------------------------------
# Selections
# -------------------------------
try:
    mep_refs = uidoc.Selection.PickObjects(ObjectType.Element, "Select MEP elements")
    host_refs = uidoc.Selection.PickObjects(ObjectType.Element, "Select Host elements")
except:
    forms.alert("Selection cancelled.", exitscript=True)

mep_elems = [doc.GetElement(r.ElementId) for r in mep_refs]
host_elems = [doc.GetElement(r.ElementId) for r in host_refs]

# -------------------------------
# Clearance input
# -------------------------------
clearance = forms.ask_for_string(
    default="25", prompt="Enter clearance in mm:", title="Builder's Work"
)
try:
    clearance_mm = float(clearance)
    clearance_ft = clearance_mm / 304.8  # mm to feet
except:
    clearance_mm = 25
    clearance_ft = 25 / 304.8

# -------------------------------
# Transaction
# -------------------------------
t = Transaction(doc, "Builder's Work Openings")
t.Start()

created = 0
cat = BuiltInCategory.OST_GenericModel

def validate_extrusion_parameters(profiles, extrusion_dir, extrusion_dist):
    """
    Validate extrusion parameters before calling CreateExtrusionGeometry
    Returns True if parameters are valid, False otherwise
    """
    # Check extrusion distance
    if extrusion_dist <= 0:
        raise ValueError("Extrusion distance must be positive")
    
    # Check extrusion direction is not zero vector
    if extrusion_dir.GetLength() < 1e-6:
        raise ValueError("Extrusion direction must be non-zero")
    
    # Check each profile loop
    for profile in profiles:
        if profile.IsOpen():
            raise ValueError("Profile loops must be closed")
        
        # Check if profile is coplanar
        if not profile.IsCoplanar():
            raise ValueError("Profile loops must be coplanar")
        
        # Get profile plane and check extrusion direction
        profile_plane = profile.GetPlane()
        if profile_plane:
            profile_normal = profile_plane.Normal
            dot_product = extrusion_dir.DotProduct(profile_normal)
            
            # Check if extrusion direction is parallel to profile plane
            if abs(dot_product) < 1e-6:
                raise ValueError("Extrusion direction must not be parallel to profile plane")
    
    return True

for mep in mep_elems:
    mep_bbox = mep.get_BoundingBox(None)
    if not mep_bbox:
        continue

    # Calculate actual dimensions from bounding box
    width = (mep_bbox.Max.X - mep_bbox.Min.X) 
    height = (mep_bbox.Max.Y - mep_bbox.Min.Y)
    depth = (mep_bbox.Max.Z - mep_bbox.Min.Z)
    
    # Get center point of MEP element
    center = (mep_bbox.Min + mep_bbox.Max) / 2

    for host in host_elems:
        try:
            # Determine host orientation and coordinate system
            if isinstance(host, Wall):
                # For walls, get the wall's coordinate system
                wall_location = host.Location
                if hasattr(wall_location, 'Curve'):
                    wall_curve = wall_location.Curve
                    wall_dir = wall_curve.Direction.Normalize()
                    wall_normal = XYZ.BasisZ.CrossProduct(wall_dir).Normalize()
                    
                    # Use wall's coordinate system
                    x_axis = wall_dir
                    y_axis = wall_normal
                    z_axis = XYZ.BasisZ
                    
                    # For walls, extrusion should be perpendicular to the wall face
                    extrusion_dir = y_axis
                else:
                    # Fallback to global coordinates
                    x_axis = XYZ.BasisX
                    y_axis = XYZ.BasisY
                    z_axis = XYZ.BasisZ
                    extrusion_dir = XYZ.BasisZ
            else:
                # For floors, roofs, etc. use global coordinates
                x_axis = XYZ.BasisX
                y_axis = XYZ.BasisY
                z_axis = XYZ.BasisZ
                extrusion_dir = XYZ.BasisZ

            # Determine if MEP element is circular or rectangular
            is_circular = False
            mep_category_id = mep.Category.Id.IntegerValue
            
            # Check for circular MEP elements
            if mep_category_id in [
                int(BuiltInCategory.OST_PipeCurves),
                int(BuiltInCategory.OST_Conduit),
            ]:
                is_circular = True
            elif mep_category_id == int(BuiltInCategory.OST_DuctCurves):
                # Check if duct is round
                try:
                    shape_param = mep.get_Parameter(BuiltInParameter.RBS_DUCT_SHAPE)
                    if shape_param and shape_param.AsString() and "Round" in shape_param.AsString():
                        is_circular = True
                except:
                    pass

            profiles = []
            
            if is_circular:
                # Circular opening - get diameter from parameters or bounding box
                diameter = 0.0
                try:
                    if mep_category_id == int(BuiltInCategory.OST_PipeCurves):
                        diameter_param = mep.get_Parameter(BuiltInParameter.RBS_PIPE_OUTER_DIAMETER)
                        if diameter_param:
                            diameter = diameter_param.AsDouble()
                    elif mep_category_id == int(BuiltInCategory.OST_Conduit):
                        diameter_param = mep.get_Parameter(BuiltInParameter.RBS_CONDUIT_DIAMETER_PARAM)
                        if diameter_param:
                            diameter = diameter_param.AsDouble()
                    elif mep_category_id == int(BuiltInCategory.OST_DuctCurves):
                        diameter_param = mep.get_Parameter(BuiltInParameter.RBS_DUCT_DIAMETER_PARAM)
                        if diameter_param:
                            diameter = diameter_param.AsDouble()
                except:
                    # Fallback to bounding box dimensions
                    diameter = max(width, height)
                
                # Add clearance
                radius = (diameter / 2) + clearance_ft
                
                # Create circular opening - ensure it's in the correct plane
                if isinstance(host, Wall):
                    # For walls, create circle in YZ plane
                    arc1 = Arc.Create(center, radius, 0, 3.14159, y_axis, z_axis)
                    arc2 = Arc.Create(center, radius, 3.14159, 2 * 3.14159, y_axis, z_axis)
                else:
                    # For floors, create circle in XY plane
                    arc1 = Arc.Create(center, radius, 0, 3.14159, x_axis, y_axis)
                    arc2 = Arc.Create(center, radius, 3.14159, 2 * 3.14159, x_axis, y_axis)

                loop = CurveLoop()
                loop.Append(arc1)
                loop.Append(arc2)
                profiles = [loop]

            else:
                # Rectangular opening
                # Get actual dimensions from MEP element parameters
                actual_width = width
                actual_height = height
                
                try:
                    if mep_category_id == int(BuiltInCategory.OST_DuctCurves):
                        width_param = mep.get_Parameter(BuiltInParameter.RBS_DUCT_WIDTH_PARAM)
                        height_param = mep.get_Parameter(BuiltInParameter.RBS_DUCT_HEIGHT_PARAM)
                        if width_param and height_param:
                            actual_width = width_param.AsDouble()
                            actual_height = height_param.AsDouble()
                    elif mep_category_id == int(BuiltInCategory.OST_CableTray):
                        width_param = mep.get_Parameter(BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM)
                        height_param = mep.get_Parameter(BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM)
                        if width_param and height_param:
                            actual_width = width_param.AsDouble()
                            actual_height = height_param.AsDouble()
                except:
                    # Use bounding box dimensions if parameter access fails
                    pass
                
                # Add clearance
                x_size = actual_width + (2 * clearance_ft)
                y_size = actual_height + (2 * clearance_ft)

                # Create rectangular opening in the correct plane
                if isinstance(host, Wall):
                    # For walls, create rectangle in YZ plane
                    p1 = center + (-y_size / 2) * y_axis + (-x_size / 2) * z_axis
                    p2 = center + (y_size / 2) * y_axis + (-x_size / 2) * z_axis
                    p3 = center + (y_size / 2) * y_axis + (x_size / 2) * z_axis
                    p4 = center + (-y_size / 2) * y_axis + (x_size / 2) * z_axis
                else:
                    # For floors, create rectangle in XY plane
                    p1 = center + (-x_size / 2) * x_axis + (-y_size / 2) * y_axis
                    p2 = center + (x_size / 2) * x_axis + (-y_size / 2) * y_axis
                    p3 = center + (x_size / 2) * x_axis + (y_size / 2) * y_axis
                    p4 = center + (-x_size / 2) * x_axis + (y_size / 2) * y_axis

                loop = CurveLoop()
                loop.Append(Line.CreateBound(p1, p2))
                loop.Append(Line.CreateBound(p2, p3))
                loop.Append(Line.CreateBound(p3, p4))
                loop.Append(Line.CreateBound(p4, p1))
                profiles = [loop]

            # Determine extrusion depth based on host type
            if isinstance(host, Wall):
                # For walls, extrude through the wall thickness
                wall_thickness_param = host.get_Parameter(BuiltInParameter.WALL_ATTR_WIDTH_PARAM)
                if wall_thickness_param:
                    depth = wall_thickness_param.AsDouble() + (2 * clearance_ft)
                else:
                    depth = 1.0  # Default depth for walls
            else:
                # For floors/roofs, extrude vertically through the element
                host_bbox = host.get_BoundingBox(None)
                if host_bbox:
                    depth = (host_bbox.Max.Z - host_bbox.Min.Z) + (2 * clearance_ft)
                else:
                    depth = 2.0

            # Validate extrusion parameters before creating the solid
            try:
                validate_extrusion_parameters(profiles, extrusion_dir, depth)
            except Exception as e:
                print("Validation failed for {}: {}".format(mep.Name if mep.Name else "MEP element", str(e)))
                continue

            # Create the extrusion solid
            solid = GeometryCreationUtilities.CreateExtrusionGeometry(
                profiles, extrusion_dir, depth
            )

            # Create DirectShape
            ds = DirectShape.CreateElement(doc, ElementId(cat))
            ds.SetShape([solid])
            
            # Set the DirectShape to be visible in all views
            visibility_param = ds.get_Parameter(BuiltInParameter.ALL_MODEL_VISIBILITY)
            if visibility_param:
                visibility_param.Set(1)
            
            created += 1

        except Exception as e:
            print("Error creating opening for {}: {}".format(mep.Name if mep.Name else "MEP element", str(e)))
            continue

t.Commit()

forms.alert("Created {} Builder's Work Openings".format(created))