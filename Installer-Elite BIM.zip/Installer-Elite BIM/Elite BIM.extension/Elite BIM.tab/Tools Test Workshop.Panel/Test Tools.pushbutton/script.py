from Autodesk.Revit.DB import FilteredElementCollector, RevitLinkInstance, BuiltInCategory, FamilyInstance
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from System.Collections.Generic import List

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument
active_view = uidoc.ActiveView

linked_instances = FilteredElementCollector(doc).OfClass(RevitLinkInstance).ToElements()


element_ids_to_select = List[ElementId]()
for linked_instance in linked_instances:
    linked_doc = linked_instance.GetLinkDocument()
    if linked_doc:
        linked_levels = linked_levels = FilteredElementCollector(linked_doc) \
    .OfCategory(BuiltInCategory.OST_Levels) \
    .WhereElementIsNotElementType() \
    .ToElements()

        for level in linked_levels:
            try:
                stable_ref = linked_instance.GetRepresentation(level.Id)
                if stable_ref:
                    element = doc.GetElement(stable_ref)
                    if element:
                        element_ids_to_select.Add(element.Id)
            except:
                continue

        # Get grids from linked document
        linked_grids = FilteredElementCollector(linked_doc).OfCategory(BuiltInCategory.OST_Grids).WhereElementIsNotElementType().ToElements()
        for grid in linked_grids:
            try:
                # Create a reference to the linked element in the current document
                stable_ref = linked_instance.GetRepresentation(grid.Id)
                if stable_ref:
                    element = doc.GetElement(stable_ref)
                    if element:
                        element_ids_to_select.Add(element.Id)
            except:
                continue

# Select the elements in the UI
if element_ids_to_select.Count > 0:
    uidoc.Selection.SetElementIds(element_ids_to_select)
    TaskDialog.Show("Elements Selected", 
                   "Selected {} linked levels and grids.\n\n".format(element_ids_to_select.Count) +
                   "Right-click and use 'Hide in View' to hide them.")
else:
    TaskDialog.Show("Info", "No linked levels or grids found or they are not visible in current view.")