
# pyRevit Builder's Work Automation Script - Fully Functional

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import ObjectType
from pyrevit import revit, forms
import clr
clr.AddReference('RevitServices')
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager

doc = revit.doc
uidoc = revit.uidoc

# Helper: Convert mm to ft
def mm_to_ft(mm):
    return mm / 304.8

# Step 1: User selects MEP elements (ducts, pipes, etc.)
mep_refs = uidoc.Selection.PickObjects(ObjectType.Element, "Select MEP Elements")
mep_elems = [doc.GetElement(ref) for ref in mep_refs]

# Step 2: User selects Structural elements (walls, floors, beams)
struct_refs = uidoc.Selection.PickObjects(ObjectType.Element, "Select Structural Elements")
struct_elems = [doc.GetElement(ref) for ref in struct_refs]

# Step 3: Ask user for clearance (mm)
clearance_input = forms.ask_for_string(default="25", prompt="Enter clearance (mm):")
if not clearance_input:
    forms.alert("No clearance provided. Cancelling script.")
    script.exit()

clearance = mm_to_ft(float(clearance_input))

TransactionManager.Instance.EnsureInTransaction(doc)

for mep in mep_elems:
    mep_geo = mep.get_Geometry(Options())

    for mep_solid in mep_geo:
        if not isinstance(mep_solid, Solid):
            continue

        for struct in struct_elems:
            struct_geo = struct.get_Geometry(Options())

            for struct_solid in struct_geo:
                if not isinstance(struct_solid, Solid):
                    continue

                result = BooleanOperationsUtils.ExecuteBooleanOperation(struct_solid, mep_solid, BooleanOperationsType.Intersect)
                if result and result.Volume > 0:
                    bbox = result.GetBoundingBox()
                    min_pt = bbox.Min
                    max_pt = bbox.Max

                    # Apply clearance
                    min_pt = XYZ(min_pt.X - clearance, min_pt.Y - clearance, min_pt.Z - clearance)
                    max_pt = XYZ(max_pt.X + clearance, max_pt.Y + clearance, max_pt.Z + clearance)

                    # Get center and size
                    center = XYZ((min_pt.X + max_pt.X)/2, (min_pt.Y + max_pt.Y)/2, (min_pt.Z + max_pt.Z)/2)
                    size_x = max_pt.X - min_pt.X
                    size_y = max_pt.Y - min_pt.Y
                    size_z = max_pt.Z - min_pt.Z

                    # Create Opening Family (Void Cube)
                    opening = FreeFormElement.Create(doc, SolidUtils.CreateBox(min_pt, max_pt))
                    opening.get_Parameter(BuiltInParameter.ELEMENT_IS_CUTTING).Set(1)

                    # Cut the opening in the structural element
                    InstanceVoidCutUtils.AddInstanceVoidCut(doc, struct, opening)

TransactionManager.Instance.TransactionTaskDone()

forms.alert("Builder's Work Openings created successfully!", exitscript=True)
