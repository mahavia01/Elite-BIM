import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitServices')
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Mechanical import *
from Autodesk.Revit.UI.Selection import *
from RevitServices.Persistence import DocumentManager

doc = DocumentManager.Instance.CurrentDBDocument
uidoc = DocumentManager.Instance.CurrentUIApplication.ActiveUIDocument

# Step 1: Select Detail Lines
lines = []
try:
    refs = uidoc.Selection.PickObjects(
        ObjectType.Element, 
        "Select Detail Lines to convert to Ducts"
    )
    lines = [doc.GetElement(ref) for ref in refs]
except:
    pass  # User cancelled

# Step 2: Get Duct Type and System (hardcode or prompt)
duct_type = FilteredElementCollector(doc).OfClass(DuctType).FirstElement()
mech_system = FilteredElementCollector(doc).OfClass(MechanicalSystemType).FirstElement()
level = doc.ActiveView.GenLevel  # Or pick a level

# Step 3: Convert Lines to Ducts
new_ducts = []
with Transaction(doc, "Create Ducts from Lines") as t:
    t.Start()
    for line in lines:
        curve = line.GeometryCurve
        duct = Duct.Create(
            doc,
            mech_system.Id,
            duct_type.Id,
            level.Id,
            curve.GetEndPoint(0),
            curve.GetEndPoint(1)
        )
        new_ducts.append(duct)
    t.Commit()

