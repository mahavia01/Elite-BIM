import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitServices')
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Mechanical import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.UI import *
from pyrevit import revit, forms 
from pyrevit import *
from pyrevit import script
from Autodesk.Revit.DB.Mechanical import *


doc = revit.doc
uidoc = revit.uidoc

forms.alert("Please Select Detail Lines To Create Ducts or Pipes")
lines = []
try:
    refs = uidoc.Selection.PickObjects(
        ObjectType.Element, 
        "Select Detail Lines to convert to Ducts"
    )
    lines = [doc.GetElement(ref) for ref in refs]
except:
    pass

# If lines are selected, prompt for Duct or Pipe option
if lines:
        Button_Option_Duct_Pipe = TaskDialog.Show("Massage, Option", 'Create Duct & Pipe from Line?\n"Yes" for Duct\n"No" for Pipe', TaskDialogCommonButtons.Yes | TaskDialogCommonButtons.No | TaskDialogCommonButtons.Cancel)
        if Button_Option_Duct_Pipe == TaskDialogResult.Cancel:
            forms.alert("Operation Cancelled. Exiting.")
            script.exit()            
if not lines:
    forms.alert("No detail lines selected. Exiting.")
    script.exit()

# Model Ducts 
if TaskDialogResult.Yes == Button_Option_Duct_Pipe:
    # Get All Duct Types in the Document
    All_Duct_Types = FilteredElementCollector(doc)\
    .OfCategory(BuiltInCategory.OST_DuctCurves)\
    .OfClass(ElementType)\
    .ToElements()
    # Get all duct type Names in the document
    duct_type_names = []
    for dt in All_Duct_Types:
        try:
            type_name = dt.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
            duct_type_names.append(type_name)
        except:
            continue
    # Remove duplicates
    duct_type_names = list(set(duct_type_names))

    # Show type names in UI
    selected_type_name = forms.SelectFromList.show(
    duct_type_names,
    title="Select Duct Type to Use",
    multiselect=False,
    button_name="Use This Duct Type"
    )
    Selected_Duct_Type = None
    for duct_type in All_Duct_Types:
        if duct_type.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM).AsString() == selected_type_name:
            Selected_Duct_Type = duct_type
            break
    
    Duct_Systems = FilteredElementCollector(doc)\
        .OfClass(MechanicalSystemType)\
        .ToElements()
    mec_system_names = []
    for mech_system in Duct_Systems:
        try:
            system_name = mech_system.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
            mec_system_names.append(system_name)
        except:
            continue
    # Show Duct Systems to user
    mech_system = forms.SelectFromList.show(
        mec_system_names,
        title="Select Duct System",
        multiselect=False,
        button_name="Select"
    )
    if not mech_system:
        forms.alert("No Duct System Selected\nScript Exiting")
        script.exit()
    Selected_Mech_System = None
    for mech_system in Duct_Systems:
        if mech_system.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM).AsString() == mech_system:
            Selected_Mech_System = mech_system
            break

    # Operation _ 01 Creating Ductsdt
    if selected_type_name:
        # Get Duct Width 
        Duct_Size_Width = forms.ask_for_string(
        prompt="Enter Duct 'Width' (mm):",
        title="Duct Sizer - Width Input",
        )
        if not Duct_Size_Width:
            forms.alert("No Width Entered\nScript Exiting")
            script.exit()
        # Get Duct Height 
        Duct_Size_Height = forms.ask_for_string(
        prompt="Enter Duct 'Height' (mm):",
        title="Duct Sizer - Height Input",
        )
        if not Duct_Size_Height:
            forms.alert("No Height Entered\nScript Exiting")
            script.exit()
    else:
        forms.alert("No Duct Type Selected\nScript Exiting")
        script.exit()
    # Get All Levels in the Document
    All_Levels = FilteredElementCollector(doc)\
        .OfClass(Level)\
        .ToElements()
    # Show Levels to user
    Show_Levels = forms.SelectFromList.show(
        [level.Name for level in All_Levels],
        title="Select Level",
        multiselect=False,
        button_name="Select"
        )
    Selected_Level = None
    for lvl in All_Levels:
        if lvl.Name == Show_Levels:
            Selected_Level = lvl
            break
    if not Show_Levels:
        forms.alert("No Level Selected\nScript Exiting")
        script.exit()
    Input_for_Level = forms.ask_for_string(
        prompt="Enter Level 'Offset' (mm):",
        title="Level Offset Input",
    )
    if not Input_for_Level:
        forms.alert("No Offset Entered\nScript Exiting")
        script.exit()
    # Operation _ 02 Creating Ducts
    New_Duct = []
    T = Transaction(doc, "Create Ducts from Lines")
    T.Start()
    for line in lines:
        curve = line.GeometryCurve
        duct = Duct.Create(
            doc,
            Selected_Mech_System.Id,
            Selected_Duct_Type.Id,
            Selected_Level.Id,
            curve.GetEndPoint(0),
            curve.GetEndPoint(1)
        )
        New_Duct.append(duct)

    T.Commit()






if TaskDialogResult.No == Button_Option_Duct_Pipe:
    forms.alert("Working on this script, It will be available soon.\nPlease check back later.\nRegards from Muhammad Mahavia")
    script.exit()




mech_system = FilteredElementCollector(doc).OfClass(MechanicalSystemType).FirstElement()









