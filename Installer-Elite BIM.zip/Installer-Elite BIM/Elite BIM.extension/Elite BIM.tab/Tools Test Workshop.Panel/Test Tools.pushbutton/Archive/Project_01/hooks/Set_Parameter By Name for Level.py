import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitServices')
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Mechanical import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.UI import *
from pyrevit import revit, forms 
from pyrevit import *
from pyrevit import script
from Autodesk.Revit.DB.Mechanical import *


doc = revit.doc
uidoc = revit.uidoc


User_Selection_For_Element = uidoc.Selection.PickObjects(ObjectType.Element, "Select an element to move")
Elements = [doc.GetElement(ref) for ref in User_Selection_For_Element]

All_Levels = FilteredElementCollector(doc).OfClass(Level).ToElements()
Level_Names = []
for lvl in All_Levels:
    Level_Names.append(lvl.Name)

User_Selection = forms.SelectFromList.show(Level_Names, title="Select Level", multiselect=False)

Selected_Level = None
if User_Selection:
    for lvl in All_Levels:
        if lvl.Name == User_Selection:
            Selected_Level = lvl
            break
for ref in User_Selection_For_Element:
    element = doc.GetElement(ref)
    t = Transaction(doc, "Move Element to Level")
    t.Start()
    param = element.LookupParameter("Reference Level")
    param.Set(Selected_Level.Id)
    t.Commit()

