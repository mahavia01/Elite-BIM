from Autodesk.Revit.DB import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.UI import *
from pyrevit import revit, forms

doc = revit.doc
uidoc = revit.uidoc

User_Selection = uidoc.Selection.PickObjects(ObjectType.Element, "Select elements to get their IDs")
Element = [doc.GetElement(id) for id in User_Selection]

T = Transaction(doc, "Set Parameter Value")
T.Start()

User_Input_01 = forms.ask_for_string("Enter Parameter name")


parameters = [param for elem in Element for param in elem.Parameters]
for param in parameters:
    if param.Definition.Name == User_Input_01:
        User_Input_02 = forms.ask_for_string("Enter value for parameter")
        param.Set(User_Input_02)
        forms.alert("Parameter value set successfully.")
        break
else:
    forms.alert("Parameter not found.")

T.Commit()