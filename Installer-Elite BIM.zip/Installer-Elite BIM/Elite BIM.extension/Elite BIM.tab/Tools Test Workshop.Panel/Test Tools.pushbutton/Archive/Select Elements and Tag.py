from Autodesk.Revit.DB import *
from Autodesk.Revit.UI.Selection import *
from pyrevit import revit, forms

doc = revit.doc
uidoc = revit.uidoc
view = doc.ActiveView

# Prompt user to select elements
user_selection = uidoc.Selection.PickObjects(ObjectType.Element, "Select elements to tag")
elements = [doc.GetElement(id) for id in user_selection]

# Start transaction
t = Transaction(doc, "Tag Selected Elements")
t.Start()

for elem in elements:
    location = elem.Location

    # Determine a valid point to place the tag
    if isinstance(location, LocationPoint):
        tag_point = location.Point
    elif isinstance(location, LocationCurve):
        tag_point = location.Curve.Evaluate(0.5, True)
    else:
        continue  # Skip elements with no taggable location

    try:
        # Create a tag (category tag)
        tag = IndependentTag.Create(
            doc,
            view.Id,
            Reference(elem),
            False,
            TagMode.TM_ADDBY_CATEGORY,
            TagOrientation.Horizontal,
            tag_point
        )
    except:
        continue  # Skip if tag cannot be created for this element

t.Commit()

forms.alert("Tags placed on selected elements.")
