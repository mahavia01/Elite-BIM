import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitServices')
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Mechanical import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.UI import *
from pyrevit import revit, forms 
from pyrevit import *

doc = revit.doc
uidoc = revit.uidoc

forms.alert("Please Select Detail Lines To Create Ducts or Pipes")
lines = []
try:
    refs = uidoc.Selection.PickObjects(
        ObjectType.Element, 
        "Select Detail Lines to convert to Ducts"
    )
    lines = [doc.GetElement(ref) for ref in refs]
except:
    pass  # User cancelled

if lines:
        Button_Option_Duct_Pipe = TaskDialog.Show("Massage, Option", 'Create Duct & Pipe from Line?\n"Yes" for Duct\n"No" for Pipe', TaskDialogCommonButtons.Yes | TaskDialogCommonButtons.No | TaskDialogCommonButtons.Cancel)
        if Button_Option_Duct_Pipe == TaskDialogResult.Cancel:
            forms.alert("Operation Cancelled. Exiting.")
            exit()
             

if not lines:
    forms.alert("No detail lines selected. Exiting.")
    exit()
else:
    Duct_Size_Width = forms.ask_for_string(
    prompt="Enter Duct 'Width' (mm):",
    title="Duct Sizer - Width Input",
    )

    Duct_Size_Height = forms.ask_for_string(
    prompt="Enter Duct 'Height' (mm):",
    title="Duct Sizer - Height Input",
    )



# Step 2: Get Duct Type and System (hardcode or prompt)
duct_type = FilteredElementCollector(doc).OfClass(DuctType).FirstElement()
mech_system = FilteredElementCollector(doc).OfClass(MechanicalSystemType).FirstElement()
level = doc.ActiveView.GenLevel  # Or pick a level

# Step 3: Convert Lines to Ducts
new_ducts = []
with Transaction(doc, "Create Ducts from Lines") as t:
    t.Start()
    for line in lines:
        curve = line.GeometryCurve
        duct = Duct.Create(
            doc,
            mech_system.Id,
            duct_type.Id,
            level.Id,
            curve.GetEndPoint(0),
            curve.GetEndPoint(1)
        )
        new_ducts.append(duct)
    t.Commit()

