import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")
clr.AddReference("PresentationFramework")
clr.AddReference("PresentationCore")
clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Net")

from Autodesk.Revit.UI import *
from Autodesk.Revit.DB import *
from System.Windows import *
from System.Windows.Controls import *
from System.Windows import TextWrapping
from System.Net import *
from System.Text import *
from System.ComponentModel import BackgroundWorker
import json
import re
import random

class RevitSearchBar:
    def __init__(self):
        self.window = Window()
        self.window.Title = "Revit Smart Search"
        self.window.Width = 600
        self.window.Height = 500
        self.window.WindowStartupLocation = WindowStartupLocation.CenterScreen
        
        # Create UI elements
        stack_panel = StackPanel()
        stack_panel.Margin = Thickness(15)
        
        # Search box
        search_label = Label()
        search_label.Content = "Ask anything about Revit:"
        search_label.Margin = Thickness(0, 0, 0, 10)
        
        self.search_box = TextBox()
        self.search_box.Height = 25
        self.search_box.Margin = Thickness(0, 0, 0, 10)
        
        # Search button
        self.search_btn = Button()
        self.search_btn.Content = "Search Google"
        self.search_btn.Height = 30
        self.search_btn.Margin = Thickness(0, 0, 0, 10)
        self.search_btn.Click += self.start_search
        
        # Progress bar
        self.progress_bar = ProgressBar()
        self.progress_bar.Height = 10
        self.progress_bar.Margin = Thickness(0, 0, 0, 10)
        self.progress_bar.Visibility = Visibility.Collapsed
        
        # Results box
        results_label = Label()
        results_label.Content = "Search Results:"
        results_label.Margin = Thickness(0, 0, 0, 5)
        
        self.results_box = TextBox()
        self.results_box.Height = 250
        self.results_box.IsReadOnly = True
        self.results_box.TextWrapping = TextWrapping.Wrap
        self.results_box.VerticalScrollBarVisibility = ScrollBarVisibility.Auto
        
        # Copy button
        copy_btn = Button()
        copy_btn.Content = "Copy Results"
        copy_btn.Height = 30
        copy_btn.Margin = Thickness(0, 10, 0, 0)
        copy_btn.Click += self.copy_to_clipboard
        
        # Add to UI
        stack_panel.Children.Add(search_label)
        stack_panel.Children.Add(self.search_box)
        stack_panel.Children.Add(self.search_btn)
        stack_panel.Children.Add(self.progress_bar)
        stack_panel.Children.Add(results_label)
        stack_panel.Children.Add(self.results_box)
        stack_panel.Children.Add(copy_btn)
        
        self.window.Content = stack_panel
        
        # Setup background worker for async search
        self.worker = BackgroundWorker()
        self.worker.DoWork += self.do_search
        self.worker.RunWorkerCompleted += self.search_completed
    
    def start_search(self, sender, e):
        query = self.search_box.Text.strip()
        if not query:
            self.results_box.Text = "Please enter a search query."
            return
        
        # Show progress and disable UI
        self.progress_bar.Visibility = Visibility.Visible
        self.progress_bar.IsIndeterminate = True
        self.search_btn.IsEnabled = False
        self.results_box.Text = "Searching Revit resources... Please wait."
        
        # Start async search
        self.worker.RunWorkerAsync(query)
    
    def do_search(self, sender, e):
        query = e.Argument.ToString()
        
        try:
            # Enhanced Revit-specific search with multiple approaches
            enhanced_query = "Revit " + query + " site:stackoverflow.com OR site:autodesk.com OR site:revitforum.org"
            
            # Try multiple user agents to avoid blocking
            user_agents = [
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
            ]
            
            # Create web client with random user agent
            client = WebClient()
            client.Encoding = Encoding.UTF8
            client.Headers.Add("User-Agent", random.choice(user_agents))
            client.Headers.Add("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            client.Headers.Add("Accept-Language", "en-US,en;q=0.5")
            
            # URL encode the query
            url = "https://www.google.com/search?q=" + WebUtility.UrlEncode(enhanced_query) + "&num=10"
            
            # Download search results
            html_content = client.DownloadString(url)
            
            # Parse results with improved method
            results = self.parse_google_results(html_content, query)
            
            if "No results found" in results:
                # Fallback: Provide helpful Revit resources
                results = self.get_revit_resources_fallback(query)
            
            e.Result = results
            
        except WebException as web_ex:
            if "403" in str(web_ex) or "429" in str(web_ex):
                e.Result = "Google is blocking automated requests. Please try again later or use a different search approach."
            else:
                e.Result = "Network error: " + str(web_ex)
        except Exception as ex:
            e.Result = "Error: " + str(ex)
    
    def parse_google_results(self, html_content, original_query):
        """Improved HTML parsing to extract search results"""
        try:
            # Multiple patterns to catch different Google result formats
            patterns = [
                r'<div class="g"[^>]*>(.*?)</div></div></div></div>',
                r'<h3[^>]*><a[^>]*>(.*?)</a></h3>.*?<span[^>]*>(.*?)</span>',
                r'<div class="rc"[^>]*>.*?<h3[^>]*>(.*?)</h3>.*?<div class="s"[^>]*>(.*?)</div>'
            ]
            
            results = []
            
            for pattern in patterns:
                matches = re.findall(pattern, html_content, re.DOTALL | re.IGNORECASE)
                if matches:
                    for match in matches:
                        if isinstance(match, tuple):
                            title, snippet = match
                        else:
                            title = match
                            snippet = ""
                        
                        # Clean HTML tags
                        title = re.sub('<[^>]*>', '', title).strip()
                        snippet = re.sub('<[^>]*>', '', snippet).strip()
                        
                        if title and len(title) > 10:  # Basic validation
                            results.append((title, snippet))
            
            if not results:
                return "No results found. Try a different query."
            
            # Format results
            formatted_results = "Google Search Results for: " + original_query + "\n\n"
            formatted_results += "=" * 60 + "\n\n"
            
            for i, (title, snippet) in enumerate(results[:5]):  # Top 5 results
                formatted_results += "Result " + str(i + 1) + ":\n"
                formatted_results += "Title: " + title + "\n"
                if snippet:
                    formatted_results += "Description: " + snippet + "\n"
                formatted_results += "-" * 40 + "\n\n"
            
            formatted_results += "Tip: Visit the actual web pages for detailed answers."
            
            return formatted_results
            
        except Exception as e:
            return "Failed to parse results. Google may have changed their HTML structure."
    
    def get_revit_resources_fallback(self, query):
        """Provide helpful Revit resources when search fails"""
        resources = [
            "Autodesk Knowledge Network: https://knowledge.autodesk.com",
            "Revit Forum: https://www.revitforum.org",
            "Stack Overflow Revit Questions: https://stackoverflow.com/questions/tagged/revit",
            "Autodesk Revit Help Documentation: https://help.autodesk.com/view/RVT/2024/ENU/",
            "Revit API Developers Guide: https://www.revitapidocs.com"
        ]
        
        response = "No direct search results found for: " + query + "\n\n"
        response += "Recommended Revit Resources:\n" + "=" * 40 + "\n\n"
        
        for i, resource in enumerate(resources, 1):
            response += str(i) + ". " + resource + "\n"
        
        response += "\nTry searching these resources directly for: " + query
        
        return response
    
    def search_completed(self, sender, e):
        # Hide progress and enable UI
        self.progress_bar.Visibility = Visibility.Collapsed
        self.progress_bar.IsIndeterminate = False
        self.search_btn.IsEnabled = True
        
        # Display results
        if e.Error:
            self.results_box.Text = "Search failed: " + str(e.Error)
        else:
            self.results_box.Text = e.Result.ToString()
    
    def copy_to_clipboard(self, sender, e):
        if self.results_box.Text and not self.results_box.Text.startswith("Please enter"):
            try:
                Clipboard.SetText(self.results_box.Text)
                self.results_box.Text += "\n\nResults copied to clipboard!"
            except Exception as ex:
                self.results_box.Text += "\n\nCopy failed: " + str(ex)
    
    def show(self):
        self.window.ShowDialog()

# Run the search bar
search_tool = RevitSearchBar()
search_tool.show()