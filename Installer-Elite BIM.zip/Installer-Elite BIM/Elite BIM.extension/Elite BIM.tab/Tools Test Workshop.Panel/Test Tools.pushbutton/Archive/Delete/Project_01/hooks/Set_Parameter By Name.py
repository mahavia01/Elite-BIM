import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitServices')
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Mechanical import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.UI import *
from pyrevit import revit, forms 
from pyrevit import *
from pyrevit import script
from Autodesk.Revit.DB.Mechanical import *

doc = revit.doc
uidoc = revit.uidoc


User_Selection = uidoc.Selection.PickObjects(ObjectType.Element, "Select Ducts")
Ducts_All = []


for ref in User_Selection:
    duct = doc.GetElement(ref)
    Ducts_All.append(duct)
Input_Parameter = forms.ask_for_string(
    prompt="Enter Parameter Value",
    default="Width",
    title="Parameter Input"
)

T = Transaction(doc, "Set Duct Parameter")
T.Start()
for ducts in Ducts_All:
    param = ducts.LookupParameter("Width")
    param.Set(float(Input_Parameter) / 12 )
T.Commit()



# if mech_system.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM).AsString() == mech_system:
