import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitServices')
from Autodesk.Revit.DB import *
from pyrevit import revit, forms, script


doc = revit.doc

# For Checking Schedules
required_Schedules = [
    "QIC_BIM_USES",
    "QIC_MULTI CATEGORY SCHEDULE",
    "QIC_ASSET_INFORMATION",
    "QIC_4D & 5D INFORMATION",
    "QIC MODEL ISSUE DATA LOG"
]

schedules = FilteredElementCollector(doc).OfClass(ViewSchedule).ToElements()
schedule_names = [s.Name for s in schedules]

missing = []
for s in required_Schedules:
    if not any(s in name for name in schedule_names):
        missing.append(s)

if not missing:
    forms.alert("All required schedules (by keyword match) exist in the model!", title="Schedule Check")
else:
    message = "The following schedule names were not found in any schedule name:\n\n"
    message += "\n".join(missing)
    forms.alert(message, title="Missing Schedule Names", warn_icon=True)


# For Checking Publish Sets 

All_Sets = FilteredElementCollector(doc).OfClass(ViewSheetSet).ToElements()
All_Set_Names = [s.Name for s in All_Sets]
Required_Set = ["Construction Document LOD-400"]
Missing_Set = []

for s in Required_Set:
    if not any(s in name for name in All_Set_Names):
        Missing_Set.append(s)
if not Missing_Set:
    forms.alert("No Missing Publish Set", title="Missing publish Set", warn_icon=False)
else:
    massage = "\n".join(Missing_Set)
    forms.alert(massage, title="Missing Publish Set", warn_icon=False)