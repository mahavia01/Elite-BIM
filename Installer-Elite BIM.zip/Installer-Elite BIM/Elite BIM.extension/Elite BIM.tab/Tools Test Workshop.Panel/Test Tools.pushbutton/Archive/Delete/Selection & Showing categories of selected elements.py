# Imports
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI.Selection import *
from pyrevit import revit, forms


# Get the current document and UIDocument
doc = revit.doc
uidoc = revit.uidoc

# User Selection
Selection = uidoc.Selection.PickObjects(ObjectType.Element, "Pick Objects")
# Collecting IDs and Categories of the selected elements
Selection_ID = []
for sel in Selection:
    IDs = doc.GetElement(sel.ElementId)
    Selection_ID.append(IDs)

Selection_Category = []
for sel in Selection_ID:
    Cat = sel.Category.Name
    Selection_Category.append(Cat)
# Displaying the selected categories in an alert
forms.alert("You have selected:\n" + "\n".join(Selection_Category))