from Autodesk.Revit.DB import FilteredElementCollector, RevitLinkInstance, Transaction
from Autodesk.Revit.UI import TaskDialog 
from pyrevit import revit 

doc = revit.doc 

All_Links = FilteredElementCollector(doc).OfClass(RevitLinkInstance).ToElements()
t = Transaction(doc, "Unpin Elements")
t.Start()


for s in All_Links:
    s.Pinned = False

t.Commit()
TaskDialog.Show("Result", "{} links unpinned.".format(len(All_Links)))
