import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitServices')
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Mechanical import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.UI import *
from pyrevit import revit, script, forms 

doc = revit.doc
uidoc = revit.uidoc


forms.alert("This Tool Is Not Available At This Time (Under Pregress).\nPlease Check Back Latter.")
script.exit()


forms.alert("Select Lines To Convert Into Ducts", warn_icon = False)
lines = []
try:
    refs = uidoc.Selection.PickObjects(
        ObjectType.Element, 
        "Select Detail Lines to convert to Ducts"
    )
    lines = [doc.GetElement(ref) for ref in refs]
except:
    forms.alert("No Lines Selected\nExiting")  
    script.exit()

duct_type_ref = FilteredElementCollector(doc).OfClass(DuctType).ToElements()
duct_type_dict = {}
for dt in duct_type_ref:
    names = dt.LookupParameter("Type Name").AsString()
    duct_type_dict.update({names: dt})  
selected_duct_name = forms.SelectFromList.show(
    sorted(duct_type_dict.keys()),
    title="Select Duct Type",
    multiselect=False
)
if not selected_duct_name:
    forms.alert("No Duct Type Selected\nExiting")
    script.exit()
duct_type = duct_type_dict[selected_duct_name] 

mech_system_ref = FilteredElementCollector(doc).OfClass(MechanicalSystemType).ToElements()
mech_system_dect = {}
for ms in mech_system_ref:
    names = ms.LookupParameter("Type Name").AsString()
    mech_system_dect.update({names: ms})

Selected_Mechanical_system = forms.SelectFromList.show(
    sorted(mech_system_dect.keys()),
    title="Selecte Mechanical System",
    multiselect=False
)
if not Selected_Mechanical_system:
    forms.alert("No Mechanical System Selected\nExiting")
    script.exit()

mech_system = mech_system_dect[Selected_Mechanical_system]

Duct_Width = forms.ask_for_string(prompt="Enter Duct Width in mm", title="Enter Width")
if not Duct_Width:
    forms.alert("No Width Entered\nScript Exiting")
    script.exit()
Duct_Height = forms.ask_for_string(prompt="Enter Duct Height in mm", title="Enter Height")
if not Duct_Height:
    forms.alert("No Height Entered\nScript Exiting")
    script.exit()
Ofset_from_Level = forms.ask_for_string(prompt="Enter Duct Height form Level in mm", title="Height Ofset")
if not Ofset_from_Level:
    forms.alert("No Height Entered\nScript Exiting")
    script.exit()

level = doc.ActiveView.GenLevel

new_ducts = []
with Transaction(doc, "Create Ducts from Lines") as t:
    t.Start()
    for line in lines:
        curve = line.GeometryCurve
        duct = Duct.Create(
            doc,
            mech_system.Id,
            duct_type.Id,
            level.Id,
            curve.GetEndPoint(0),
            curve.GetEndPoint(1)
        )
        new_ducts.append(duct)   
    t.Commit()
    
t = Transaction(doc, "Set Duct Parameters")
t.Start()
for Ducts in new_ducts:
    param_width = Ducts.LookupParameter("Width")
    param_height = Ducts.LookupParameter("Height")
    param_offset = Ducts.LookupParameter("Lower End Bottom Elevation")
    param_width.Set(float(Duct_Width) / 304.8)  # Convert feet to mm
    param_height.Set(float(Duct_Height) / 304.8)  # Convert feet to mm
    param_offset.Set(float(Ofset_from_Level) / 304.8)  # Convert feet to mm

t.Commit()

Dialog = TaskDialog("Conversion Complete")
Dialog.MainInstruction = "All Lines Are Successfully Converted Into Ducts\nThanks For Using Elit-BIM Tool"
Dialog.MainContent = "Tool Created By Muhammad Mahavia"
Dialog.Show()