# This script is designed by **Muhammad Mahavia**
# for any help contact at m.mahavia01@gmail.com

from pyrevit import revit
from Autodesk.Revit.DB import FilteredElementCollector, ElementId
from System.Windows.Forms import Application, Form, Label, ListView, View, Button, Panel
from System.Drawing import Font, FontStyle, Color, Size, Point

try:
    from Autodesk.Revit.DB.Electrical import PanelScheduleView, PanelScheduleTemplate
except:
    from Autodesk.Revit.DB import PanelScheduleView
    try:
        from Autodesk.Revit.DB import PanelScheduleTemplate
    except:
        PanelScheduleTemplate = None

doc = revit.doc


panel_schedules = list(FilteredElementCollector(doc).OfClass(PanelScheduleView).ToElements())
total_count = len(panel_schedules)

results = []
with_template = 0
without_template = 0

for ps in panel_schedules:
    sched_name = ps.Name
    tmpl_name = "<No Template>"
    has_template = False

    tmpl_id = None
    try:
        tmpl_id = ps.GetTemplate()
    except:
        try:
            tmpl_id = ps.ViewTemplateId
        except:
            tmpl_id = None

    if tmpl_id and tmpl_id != ElementId.InvalidElementId:
        tmpl_el = doc.GetElement(tmpl_id)
        if tmpl_el:
            try:
                tmpl_name = tmpl_el.Name
            except:
                tmpl_name = str(tmpl_el)
            has_template = True

    if has_template:
        with_template += 1
    else:
        without_template += 1

    results.append((sched_name, tmpl_name, has_template))

percent = int(round((with_template / float(total_count)) * 100)) if total_count > 0 else 0


# ----------------- WinForms Dashboard -----------------
class PanelScheduleDashboard(Form):
    def __init__(self):
        self.Text = "Panel Schedule Result"
        self.Size = Size(800, 600)

        title = Label()
        title.Text = " Panel Schedule Templates"
        title.Font = Font("Arial", 14, FontStyle.Bold)
        title.AutoSize = True
        title.Location = Point(20, 20)
        self.Controls.Add(title)

        summary = Label()
        summary.Text = "Total Number Of Panels: {}".format(
            total_count
        )
        summary.Font = Font("Arial", 10, FontStyle.Regular)
        summary.AutoSize = True
        summary.Location = Point(20, 60)
        self.Controls.Add(summary)

        # Progress Bar
        bar_back = Panel()
        bar_back.Size = Size(400, 20)
        bar_back.Location = Point(20, 90)
        bar_back.BackColor = Color.LightGray
        self.Controls.Add(bar_back)

        bar_fill = Panel()
        bar_fill.Size = Size(int(400 * (percent / 100.0)), 20)
        bar_fill.Location = Point(20, 90)
        bar_fill.BackColor = Color.White if percent > 70 else (Color.Orange if percent > 40 else Color.Red)
        self.Controls.Add(bar_fill)

        # ListView
        lv = ListView()
        lv.View = View.Details
        lv.Size = Size(740, 350)
        lv.Location = Point(20, 130)
        lv.Columns.Add("Panel Schedule Name", 300)
        lv.Columns.Add("Template", 300)
        lv.Columns.Add("Status", 100)

        for sched_name, tmpl_name, has_template in results:
            status = "Available" if has_template else " Missing"
            item = lv.Items.Add(sched_name)
            item.SubItems.Add(tmpl_name)
            item.SubItems.Add(status)
            item.BackColor = Color.White if has_template else Color.LightCoral

        self.Controls.Add(lv)

        # Close button
        btn_close = Button()
        btn_close.Text = "Close"
        btn_close.Location = Point(650, 500)
        btn_close.Click += self.close_clicked
        self.Controls.Add(btn_close)

    def close_clicked(self, sender, args):
        self.Close()


# ----------------- Run -----------------
form = PanelScheduleDashboard()
form.ShowDialog()
