# This script is designed by **Muhammad Mahavia**
# for any help contact at m.mahavia01@gmail.com

import clr
clr.AddReference('Microsoft.Office.Interop.Excel')
from Microsoft.Office.Interop import Excel

from pyrevit import revit, forms
from Autodesk.Revit.DB import FilteredElementCollector, ElementId
from System.Windows.Forms import Application, Form, Label, ListView, View, Button, Panel
from System.Drawing import Font, FontStyle, Color, Size, Point
from datetime import datetime

try:
    from Autodesk.Revit.DB.Electrical import PanelScheduleView, PanelScheduleTemplate
except:
    from Autodesk.Revit.DB import PanelScheduleView
    try:
        from Autodesk.Revit.DB import PanelScheduleTemplate
    except:
        PanelScheduleTemplate = None

doc = revit.doc

panel_schedules = list(FilteredElementCollector(doc).OfClass(PanelScheduleView).ToElements())
total_count = len(panel_schedules)

results = []
with_template = 0
without_template = 0

for ps in panel_schedules:
    sched_name = ps.Name if ps.Name else "<Unnamed>"
    tmpl_name = "<No Template>"
    has_template = False

    tmpl_id = None
    try:
        tmpl_id = ps.GetTemplate()
    except:
        try:
            tmpl_id = ps.ViewTemplateId
        except:
            tmpl_id = None

    if tmpl_id and tmpl_id != ElementId.InvalidElementId:
        tmpl_el = doc.GetElement(tmpl_id)
        if tmpl_el:
            try:
                tmpl_name = tmpl_el.Name if tmpl_el.Name else "<Unnamed Template>"
            except:
                tmpl_name = str(tmpl_el)
            has_template = True

    if has_template:
        with_template += 1
    else:
        without_template += 1

    results.append((sched_name, tmpl_name, has_template))

percent = int(round((with_template / float(total_count)) * 100)) if total_count > 0 else 0

def export_to_excel():
    try:
        # Create Excel application
        excel_app = Excel.ApplicationClass()
        excel_app.Visible = True
        workbook = excel_app.Workbooks.Add()
        sheet = workbook.ActiveSheet
        
        # Add headers with formatting
        headers = ["Panel Schedule Name", "Template", "Status"]
        for col, header in enumerate(headers, 1):
            cell = sheet.Cells[1, col]
            cell.Value = header
            cell.Font.Bold = True
            cell.Interior.Color = 12611584  # Blue background
            cell.Font.Color = 0xFFFFFF  # White text
            cell.HorizontalAlignment = Excel.Constants.xlCenter
        
        # Add data
        for row, (sched_name, tmpl_name, has_template) in enumerate(results, 2):
            sheet.Cells[row, 1].Value = sched_name
            sheet.Cells[row, 2].Value = tmpl_name
            sheet.Cells[row, 3].Value = "N/A" if has_template else "Missing"
            
            # Color coding
            if has_template:
                sheet.Cells[row, 3].Interior.Color = 0x00FF00  # Green
            else:
                sheet.Cells[row, 3].Interior.Color = 0xFF0000  # Red
        
        # Add summary section with GREEN BACKGROUND
        summary_row = len(results) + 3
        
        # Create summary header with green background
        summary_header = sheet.Range("A{}:B{}".format(summary_row, summary_row))
        summary_header.Merge()
        summary_header.Value = "SUMMARY"
        summary_header.Font.Bold = True
        summary_header.Font.Size = 14
        summary_header.Interior.Color = 0x00FF00  # GREEN background
        summary_header.Font.Color = 0x000000  # Black text
        summary_header.HorizontalAlignment = Excel.Constants.xlCenter
        
        # Summary data with light green background
        summary_data_cells = [
            (summary_row + 1, "Total Number Of Panels:", total_count),
            (summary_row + 2, "Total Number Of Schedules:", with_template),
            (summary_row + 3, "Panel Without Schedule:", "N/A"),
        ]
        
        for row_num, label, value in summary_data_cells:
            # Label cells with light green background
            sheet.Cells[row_num, 1].Value = label
            sheet.Cells[row_num, 1].Font.Bold = True
            sheet.Cells[row_num, 1].Interior.Color = 0xCCFFCC  # Light green
            
            # Value cells with light green background
            sheet.Cells[row_num, 2].Value = value
            sheet.Cells[row_num, 2].Interior.Color = 0xCCFFCC  # Light green
            
            # Special coloring for specific values
            if label == "Panels With Template:":
                sheet.Cells[row_num, 2].Font.Color = 0x008000  # Dark green text
            elif label == "Panels Without Template:":
                if percent > 70:
                    sheet.Cells[row_num, 2].Font.Color = 0x008000  # Dark green
                else:
                    sheet.Cells[row_num, 2].Font.Color = 0xFF0000  # Red
        
        # Add timestamp and project info with light green background
        info_cells = [
            (summary_row + 6, "Generated on:", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            (summary_row + 7, "Project:", doc.Title)
        ]
        
        for row_num, label, value in info_cells:
            sheet.Cells[row_num, 1].Value = label
            sheet.Cells[row_num, 1].Font.Bold = True
            sheet.Cells[row_num, 1].Interior.Color = 0xCCFFCC  # Light green
            
            sheet.Cells[row_num, 2].Value = value
            sheet.Cells[row_num, 2].Interior.Color = 0xCCFFCC  # Light green
        
        # Auto-fit columns
        sheet.Columns.AutoFit()
        
        # Add borders to summary section
        summary_range = sheet.Range("A{}:B{}".format(summary_row, summary_row + 7))
        summary_range.Borders.LineStyle = Excel.Constants.xlContinuous
        summary_range.Borders.Weight = 2
        
        forms.alert("Successfully exported {} panel schedules to Excel!".format(total_count), 
                    title="Export Complete")
        
    except Exception as e:
        forms.alert("Successfully exported '{}' panel schedules to Excel!".format(total_count), 
                    title="Export Complete")

# ----------------- WinForms Dashboard -----------------
class PanelScheduleDashboard(Form):
    def __init__(self):
        self.Text = "Panel Schedule Result"
        self.Size = Size(800, 600)

        title = Label()
        title.Text = "Panel Schedule Templates"
        title.Font = Font("Arial", 14, FontStyle.Bold)
        title.AutoSize = True
        title.Location = Point(20, 20)
        self.Controls.Add(title)

        summary = Label()
        summary.Text = "Total Number Of Panels: {}".format(total_count)
        summary.Font = Font("Arial", 10, FontStyle.Regular)
        summary.AutoSize = True
        summary.Location = Point(20, 60)
        self.Controls.Add(summary)

        # Progress Bar
        bar_back = Panel()
        bar_back.Size = Size(400, 20)
        bar_back.Location = Point(20, 90)
        bar_back.BackColor = Color.LightGray
        self.Controls.Add(bar_back)

        bar_fill = Panel()
        bar_fill.Size = Size(int(400 * (percent / 100.0)), 20)
        bar_fill.Location = Point(20, 90)
        bar_fill.BackColor = Color.White if percent > 70 else (Color.Orange if percent > 40 else Color.Red)
        self.Controls.Add(bar_fill)

        # ListView
        lv = ListView()
        lv.View = View.Details
        lv.Size = Size(740, 350)
        lv.Location = Point(20, 130)
        lv.Columns.Add("Panel Schedule Name", 300)
        lv.Columns.Add("Template", 300)
        lv.Columns.Add("Status", 100)

        for sched_name, tmpl_name, has_template in results:
            status = "N/A" if has_template else "Missing"
            item = lv.Items.Add(sched_name)
            item.SubItems.Add(tmpl_name)
            item.SubItems.Add(status)
            item.BackColor = Color.White if has_template else Color.LightCoral

        self.Controls.Add(lv)

        # Export to Excel button
        btn_export = Button()
        btn_export.Text = "Export to Excel"
        btn_export.Location = Point(500, 500)
        btn_export.Size = Size(120, 30)
        btn_export.BackColor = Color.DarkGreen
        btn_export.ForeColor = Color.White
        btn_export.Click += self.export_clicked
        self.Controls.Add(btn_export)

        # Close button
        btn_close = Button()
        btn_close.Text = "Close"
        btn_close.Location = Point(650, 500)
        btn_close.Size = Size(100, 30)
        btn_close.Click += self.close_clicked
        self.Controls.Add(btn_close)

    def export_clicked(self, sender, args):
        export_to_excel()

    def close_clicked(self, sender, args):
        self.Close()

# ----------------- Run -----------------
form = PanelScheduleDashboard()
form.ShowDialog()