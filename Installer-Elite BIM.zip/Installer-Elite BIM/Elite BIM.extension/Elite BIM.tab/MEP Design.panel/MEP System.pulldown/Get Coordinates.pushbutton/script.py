import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")
clr.AddReference("RevitServices")

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *

from pyrevit import revit, script, forms
from Autodesk.Revit.UI.Selection import ObjectType

doc = revit.doc
uidoc = revit.uidoc

forms.alert('Select elements to set their coordinates into parameters', warn_icon=False)
try:
    selection_refs = uidoc.Selection.PickObjects(ObjectType.Element, "Select elements to process")
    selected_elements = [doc.GetElement(ref) for ref in selection_refs]
    
except:
    forms.alert('Selection cancelled. Exiting...')
    script.exit()   

if not selection_refs:
    forms.alert('No Element Selected\nExiting...')
    script.exit()  



for elem in selected_elements:
    param_easting = elem.LookupParameter("Easting")
    param_northing = elem.LookupParameter("Northing")
    param_elevation = elem.LookupParameter("Elevation")
    
    if param_easting is None or param_northing is None or param_elevation is None:
        forms.alert('Selected Elements does not have required parameters.\nExiting...')
        script.exit()

else:
    t = Transaction(doc, 'Set Coordinates to Parameters')
    t.Start()
    error_elements = []

    for elem in selected_elements:
        try:
            # Get element location
            loc = elem.Location
            if loc is None:
                error_elements.append((elem.Id, "No location"))
                continue
            
            # Get coordinates based on location type 
            point = None
            if hasattr(loc, "Point") and loc.Point:
                point = loc.Point
            elif hasattr(loc, "Curve") and loc.Curve:
                point = loc.Curve.GetEndPoint(0)
            else:
                error_elements.append((elem.Id, "Unsupported location type"))
                continue
        
            easting = point.X
            northing = point.Y
            elevation = point.Z
        

            easting_m = UnitUtils.ConvertFromInternalUnits(easting, UnitTypeId.Meters)
            northing_m = UnitUtils.ConvertFromInternalUnits(northing, UnitTypeId.Meters)
            elevation_m = UnitUtils.ConvertFromInternalUnits(elevation, UnitTypeId.Meters)
        
            easting_m = round(easting_m, 3)
            northing_m = round(northing_m, 3)
            elevation_m = round(elevation_m, 3)
        
            param_easting = elem.LookupParameter("Easting")
            param_northing = elem.LookupParameter("Northing")
            param_elevation = elem.LookupParameter("Elevation")
        
            if param_easting is not None and not param_easting.IsReadOnly:
                if param_easting.StorageType == StorageType.Double:
                    param_easting.Set(easting_m)
                elif param_easting.StorageType == StorageType.String:
                    param_easting.Set(str(easting_m))
        
            if param_northing is not None and not param_northing.IsReadOnly:
                if param_northing.StorageType == StorageType.Double:
                    param_northing.Set(northing_m)
                elif param_northing.StorageType == StorageType.String:
                    param_northing.Set(str(northing_m))
        
            if param_elevation is not None and not param_elevation.IsReadOnly:
                if param_elevation.StorageType == StorageType.Double:
                    param_elevation.Set(elevation_m)
                elif param_elevation.StorageType == StorageType.String:
                    param_elevation.Set(str(elevation_m))
        
            success_count += 1
        
        except Exception as ex:
            error_elements.append((elem.Id, str(ex)))

    t.Commit()

from pyrevit import forms

forms.alert("Secussfully Processed.\nEnjoy!", title="Done", warn_icon=False)