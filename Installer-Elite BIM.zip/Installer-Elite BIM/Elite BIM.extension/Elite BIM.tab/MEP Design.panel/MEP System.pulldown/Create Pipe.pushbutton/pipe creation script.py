import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitServices')
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Mechanical import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.UI import *
from pyrevit import revit, script, forms 

doc = revit.doc
uidoc = revit.uidoc


Dialog = TaskDialog("Message")

Dialog.MainInstruction = "This Tool Is Currently Unavailable\nKindly Check In Newer Version of Elite-BIM"
Dialog.MainContent = "By Muhammad Mahavia"
Dialog.Show()

script.exit()




forms.alert("Select Lines To Convert Into Ducts\nDo not select Circular Lines or Curve Lines.", warn_icon=False)
lines = []
try:
    refs = uidoc.Selection.PickObjects(
        ObjectType.Element, 
        "Select Detail Lines to convert to Ducts"
    )
    lines = [doc.GetElement(ref) for ref in refs]
except:
    forms.alert("No Lines Selected\nExiting")  
    script.exit()


