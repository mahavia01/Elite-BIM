import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitServices')
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Mechanical import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.UI import *
from pyrevit import revit, script, forms 

doc = revit.doc
uidoc = revit.uidoc

forms.alert("Select Lines To Convert Into Ducts\nDo not select Circular Lines or Curve Lines.", warn_icon=False)
lines = []
try:
    refs = uidoc.Selection.PickObjects(
        ObjectType.Element, 
        "Select Detail Lines to convert to Ducts"
    )
    lines = [doc.GetElement(ref) for ref in refs]
except:
    forms.alert("No Lines Selected\nExiting")  
    script.exit()



duct_type_ref = FilteredElementCollector(doc).OfClass(DuctType).ToElements()
duct_type_dict = {}
for dt in duct_type_ref:
    names = dt.LookupParameter("Type Name").AsString()
    duct_type_dict.update({names: dt})  

selected_duct_name = forms.SelectFromList.show(
    sorted(duct_type_dict.keys()),
    title="Select Duct Type",
    multiselect=False
) 

if not selected_duct_name:
    forms.alert("No Duct Type Selected\nExiting")
    script.exit()
    
duct_type = duct_type_dict[selected_duct_name] 


is_round_duct = False


if "round" in selected_duct_name.lower() or "circular" in selected_duct_name.lower():
    is_round_duct = True


param_diameter = duct_type.LookupParameter("Diameter")
param_width = duct_type.LookupParameter("Width")

if param_diameter and not param_width:
    is_round_duct = True

try:
    shape_param = duct_type.get_Parameter(BuiltInParameter.RBS_CURVE_DUCT_SHAPE)
    if shape_param and shape_param.AsInteger() == 1:
        is_round_duct = True
except:
    pass



if is_round_duct:
    duct_diameter = forms.ask_for_string(
        prompt="Enter Duct Diameter in mm", 
        title="Enter Diameter for Round Duct",
        default="100"
    )
    if not duct_diameter:
        forms.alert("No Diameter Entered\nScript Exiting")
        script.exit()
else:
    duct_width = forms.ask_for_string(
        prompt="Enter Duct Width in mm", 
        title="Enter Width for Rectangular Duct",
        default="200"
    )
    if not duct_width:
        forms.alert("No Width Entered\nScript Exiting")
        script.exit()
        
    duct_height = forms.ask_for_string(
        prompt="Enter Duct Height in mm", 
        title="Enter Height for Rectangular Duct",
        default="100"
    )
    if not duct_height:
        forms.alert("No Height Entered\nScript Exiting")
        script.exit()

offset_from_level = forms.ask_for_string(
    prompt="Enter Duct Height from Level in mm", 
    title="Height Offset",
    default="2500"
)
if not offset_from_level:
    forms.alert("No Height Entered\nScript Exiting")
    script.exit()


mech_system_ref = FilteredElementCollector(doc).OfClass(MechanicalSystemType).ToElements()
mech_system_dict = {}
for ms in mech_system_ref:
    names = ms.LookupParameter("Type Name").AsString()
    mech_system_dict.update({names: ms})

selected_mech_system = forms.SelectFromList.show(
    sorted(mech_system_dict.keys()),
    title="Select Mechanical System",
    multiselect=False
)
if not selected_mech_system:
    forms.alert("No Mechanical System Selected\nExiting")
    script.exit()

mech_system = mech_system_dict[selected_mech_system]
level = doc.ActiveView.GenLevel

new_ducts = []
with Transaction(doc, "Create Ducts from Lines") as t:
    t.Start()
    for line in lines:
        curve = line.GeometryCurve
        duct = Duct.Create(
            doc,
            mech_system.Id,
            duct_type.Id,
            level.Id,
            curve.GetEndPoint(0),
            curve.GetEndPoint(1)
        )
        new_ducts.append(duct)   
    t.Commit()


t = Transaction(doc, "Set Duct Parameters")
t.Start()

for duct in new_ducts:
    param_offset = duct.LookupParameter("Bottom Elevation") or duct.LookupParameter("Offset")
    if param_offset and not param_offset.IsReadOnly:
        param_offset.Set(float(offset_from_level) / 304.8)  # Convert mm to feet
    
    if is_round_duct:
        param_diameter = duct.LookupParameter("Diameter") or duct.get_Parameter(BuiltInParameter.RBS_CURVE_DIAMETER_PARAM)
        if param_diameter and not param_diameter.IsReadOnly:
            param_diameter.Set(float(duct_diameter) / 304.8)  # Convert mm to feet
    else:
        param_width = duct.LookupParameter("Width") or duct.get_Parameter(BuiltInParameter.RBS_CURVE_WIDTH_PARAM)
        param_height = duct.LookupParameter("Height") or duct.get_Parameter(BuiltInParameter.RBS_CURVE_HEIGHT_PARAM)
        
        if param_width and not param_width.IsReadOnly:
            param_width.Set(float(duct_width) / 304.8)  # Convert mm to feet
        if param_height and not param_height.IsReadOnly:
            param_height.Set(float(duct_height) / 304.8)  # Convert mm to feet

t.Commit()

Dialog = TaskDialog("Conversion Complete")
if is_round_duct:
    Dialog.MainInstruction = "Round ducts created successfully!\nDiameter: {} mm".format(duct_diameter)
else:
    Dialog.MainInstruction = "Rectangular ducts created successfully!\nSize: {} x {} mm".format(duct_width, duct_height)
Dialog.MainContent = "Tool Created By Muhammad Mahavia\n{} ducts created from {} lines".format(len(new_ducts), len(lines))
Dialog.Show()