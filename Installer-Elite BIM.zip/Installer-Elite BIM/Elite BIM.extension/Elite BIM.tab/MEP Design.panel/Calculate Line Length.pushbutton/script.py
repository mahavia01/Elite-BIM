import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitServices')
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI.Selection import ObjectType
from pyrevit import forms, revit, script

doc = revit.doc
uidoc = revit.uidoc


try:
    massage1 = forms.alert("Please Select Lines To Calculate Total Length", warn_icon = False)
    selected_refs = uidoc.Selection.PickObjects(ObjectType.Element, "Select model/detail lines")

except:
    forms.alert("No Lines Selected\nScript Exiting...")
    script.exit()

if not selected_refs:
      forms.alert("No Lines Selected\nScript Exiting...")
      script.exit()  


total_length = 0.0
for ref in selected_refs:
    line = doc.GetElement(ref)
    param = line.LookupParameter("Length")
    if param:
        total_length += param.AsDouble()  

# Convert feet to mm (1 foot = 304.8 mm)
total_length_mm = total_length * 304.8

forms.alert("Total length of selected lines:\n{:.2f} mm".format(total_length_mm), title="Line Length Total", warn_icon = False)
