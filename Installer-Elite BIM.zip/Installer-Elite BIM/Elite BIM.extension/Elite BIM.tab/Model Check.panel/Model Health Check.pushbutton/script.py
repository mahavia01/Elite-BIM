import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitServices")
clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")
clr.AddReference("System")

from Autodesk.Revit.DB import *
from RevitServices.Persistence import DocumentManager
from System.Windows.Forms import Form, Label, Button, Panel, ListBox, FormStartPosition, BorderStyle
from System.Drawing import Font, Color, Point, Size, FontStyle
from System import EventHandler
import collections
import traceback


def safe_div_percent(passed, total):
    if total <= 0:
        return 100
    return int(round(max(0.0, min(100.0, float(passed) / float(total) * 100.0))))

def get_status_color(score):
    if score >= 80:
        return Color.Green, "EXCELLENT"
    elif score >= 60:
        return Color.Orange, "GOOD"
    elif score >= 40:
        return Color.OrangeRed, "FAIR"
    else:
        return Color.Red, "POOR"


class ModelChecks(object):
    def __init__(self, doc):
        self.doc = doc

    def regen(self):
        try:
            self.doc.Regenerate()
        except:
            pass

    def check_revit_links(self):
        self.regen()
        links = FilteredElementCollector(self.doc).OfClass(RevitLinkInstance).ToElements()
        total = len(links)
        unpinned = []
        for l in links:
            try:
                pinned = getattr(l, "Pinned", None)
                if pinned is None:
                    p = l.get_Parameter(BuiltInParameter.ELEM_LOCKED_PARAM)
                    pinned = (p.AsInteger() == 1) if p else False
                if not pinned:
                    name = getattr(l, "Name", None) or "LinkId:{}".format(l.Id.IntegerValue)
                    unpinned.append(name)
            except:
                try:
                    unpinned.append(getattr(l, "Name", "UnknownLink"))
                except:
                    unpinned.append("UnknownLink")
        pinned_count = total - len(unpinned)
        percent = safe_div_percent(pinned_count, total)
        return {"total": total, "pinned": pinned_count, "issues": unpinned, "percent": percent}

    def check_unused_family_symbols(self):
        self.regen()
        symbols = FilteredElementCollector(self.doc).OfClass(FamilySymbol).ToElements()
        symbols = [s for s in symbols if s.Family.IsEditable]
        total = len(symbols)
        instances = FilteredElementCollector(self.doc).WhereElementIsNotElementType().ToElements()
        used_type_ids = set()
        for inst in instances:
            try:
                tid = inst.GetTypeId()
                if isinstance(tid, ElementId) and tid != ElementId.InvalidElementId:
                    used_type_ids.add(tid.IntegerValue)
            except:
                continue

        unused = []
        for s in symbols:
            try:
                if s.Id.IntegerValue not in used_type_ids:
                    fam_name = getattr(s.Family, "Name", "<fam?>")
                    sym_name = getattr(s, "Name", "<type?>")
                    unused.append("{0} : {1}".format(fam_name, sym_name))
            except:
                try:
                    unused.append(getattr(s, "Name", "UnknownSymbol"))
                except:
                    unused.append("UnknownSymbol")

        used_count = total - len(unused)
        percent = safe_div_percent(used_count, total)
        return {"total": total, "used": used_count, "issues": unused, "percent": percent}



    def check_view_templates(self):
        self.regen()
        sheets = FilteredElementCollector(self.doc).OfClass(ViewSheet).ToElements()
        exclude_types = set([ViewType.Legend, ViewType.Section, ViewType.ThreeD])
        missing = []
        total_checkable = 0
        for sheet in sheets:
            for vid in sheet.GetAllPlacedViews():
                try:
                    v = self.doc.GetElement(vid)
                    if v is None: 
                        continue
                    if getattr(v, "IsTemplate", False): 
                        continue
                    if getattr(v, "ViewType", None) in exclude_types: 
                        continue
                    total_checkable += 1
                    if getattr(v, "ViewTemplateId", ElementId.InvalidElementId) == ElementId.InvalidElementId:
                        missing.append("{0} (Id:{1})".format(getattr(v, "Name", "<no name>"), v.Id.IntegerValue))
                except:
                    try:
                        missing.append(getattr(v, "Name", "UnknownView"))
                    except:
                        missing.append("UnknownView")
        good_count = total_checkable - len(missing)
        percent = safe_div_percent(good_count, total_checkable)
        return {"total": total_checkable, "good": good_count, "issues": missing, "percent": percent}


    def check_levels_grids_pinned(self):
        self.regen()
        levels = FilteredElementCollector(self.doc).OfCategory(BuiltInCategory.OST_Levels).WhereElementIsNotElementType().ToElements()
        grids = FilteredElementCollector(self.doc).OfCategory(BuiltInCategory.OST_Grids).WhereElementIsNotElementType().ToElements()

        def eval_pinned(elems):
            total = len(elems)
            unp = []
            for el in elems:
                try:
                    pinned = getattr(el, "Pinned", None)
                    if pinned is None:
                        p = el.get_Parameter(BuiltInParameter.ELEM_LOCKED_PARAM)
                        pinned = (p.AsInteger() == 1) if p else False
                    if not pinned:
                        unp.append(getattr(el, "Name", "Id:{}".format(el.Id.IntegerValue)))
                except:
                    try:
                        unp.append(getattr(el, "Name", "Id:{}".format(el.Id.IntegerValue)))
                    except:
                        unp.append("Unknown")
            pinned_count = total - len(unp)
            percent = safe_div_percent(pinned_count, total)
            return {"total": total, "pinned": pinned_count, "issues": unp, "percent": percent}

        return {"levels": eval_pinned(levels), "grids": eval_pinned(grids)}

    def check_warnings(self):
        self.regen()
        try:
            warns = self.doc.GetWarnings()
            pct = safe_div_percent(max(0, 100 - len(warns)), 100)
            return {"count": len(warns), "issues": ["Warnings count: {}".format(len(warns))], "percent": pct}
        except:
            return {"count": 0, "issues": [], "percent": 100}



# ---------------- Dashboard UI ----------------
class HealthDashboard(Form):
    def __init__(self, doc):
        Form.__init__(self)
        self.Text = "Revit Model Health Dashboard"
        self.Size = Size(980, 760)
        self.StartPosition = FormStartPosition.CenterScreen
        self.BackColor = Color.White
        self.Font = Font("Segoe UI", 10)
        self.doc = doc
        self.checker = ModelChecks(doc)
        self.ui = {}
        self.build_ui()
        self.run_and_update()

    # ---------------- Build UI ----------------
    def build_ui(self):
        header = Label()
        header.Text = "Revit Model Health Dashboard"
        header.Font = Font("Segoe UI", 16, FontStyle.Bold)
        header.ForeColor = Color.DarkBlue
        header.Location = Point(16, 12)
        header.AutoSize = True
        self.Controls.Add(header)

        # Circular overall panel
        self.ui["circle_panel"] = Panel()
        self.ui["circle_panel"].Location = Point(600, 20)
        self.ui["circle_panel"].Size = Size(150, 150)
        self.ui["circle_panel"].BackColor = Color.White
        self.Controls.Add(self.ui["circle_panel"])

        # Buttons
        refresh_btn = Button()
        refresh_btn.Text = "Refresh"
        refresh_btn.Location = Point(220, 72)
        refresh_btn.Width = 100
        refresh_btn.Height = 36
        refresh_btn.Click += lambda s, e: self.run_and_update()
        self.Controls.Add(refresh_btn)

        close_btn = Button()
        close_btn.Text = "Close"
        close_btn.Location = Point(340, 72)
        close_btn.Width = 100
        close_btn.Height = 36
        close_btn.Click += lambda s, e: self.Close()
        self.Controls.Add(close_btn)

        # Category panels
        start_x = 20
        start_y = 200
        gap_x = 12
        panel_w = 300
        panel_h = 140
        cats = ["Revit Links", "Unused Families", "View Templates", "Levels Pinned", "Grids Pinned", "Warnings"]
        positions = []
        for r in range(2):
            for c in range(3):
                x = start_x + c * (panel_w + gap_x)
                y = start_y + r * (panel_h + 18)
                positions.append((x, y))
        for i, name in enumerate(cats):
            x, y = positions[i]
            p = self.create_category_panel(name, x, y, panel_w, panel_h)
            self.Controls.Add(p)

    def create_category_panel(self, title_text, x, y, w, h):
        panel = Panel()
        panel.Location = Point(x, y)
        panel.Size = Size(w, h)
        panel.BorderStyle = BorderStyle.FixedSingle
        panel.BackColor = Color.FromArgb(250, 250, 250)

        title = Label()
        title.Text = title_text
        title.Font = Font("Segoe UI", 10, FontStyle.Bold)
        title.ForeColor = Color.DarkBlue
        title.Location = Point(8, 8)
        title.AutoSize = True
        panel.Controls.Add(title)

        pct_lbl = Label()
        pct_lbl.Text = "0%"
        pct_lbl.Font = Font("Segoe UI", 18, FontStyle.Bold)
        pct_lbl.Location = Point(8, 34)
        pct_lbl.AutoSize = True
        panel.Controls.Add(pct_lbl)

        st_lbl = Label()
        st_lbl.Text = ""
        st_lbl.Font = Font("Segoe UI", 9, FontStyle.Bold)
        st_lbl.Location = Point(120, 42)
        st_lbl.AutoSize = True
        panel.Controls.Add(st_lbl)

        bar_bg = Panel()
        bar_bg.Location = Point(8, 70)
        bar_bg.Size = Size(w - 16, 18)
        bar_bg.BackColor = Color.LightGray
        bar_bg.BorderStyle = BorderStyle.FixedSingle
        panel.Controls.Add(bar_bg)

        bar_fill = Panel()
        bar_fill.Location = Point(0, 0)
        bar_fill.Size = Size(0, 18)
        bar_fill.BackColor = Color.Green
        bar_bg.Controls.Add(bar_fill)

        issues_lbl = Label()
        issues_lbl.Text = ""
        issues_lbl.Font = Font("Segoe UI", 8)
        issues_lbl.ForeColor = Color.DarkRed
        issues_lbl.Location = Point(8, 96)
        issues_lbl.Size = Size(w - 16, 38)
        issues_lbl.AutoEllipsis = True
        panel.Controls.Add(issues_lbl)

        details_btn = Button()
        details_btn.Text = "Details"
        details_btn.Location = Point(w - 88, 8)
        details_btn.Width = 70
        details_btn.Height = 26
        panel.Controls.Add(details_btn)

        self.ui[title_text] = {
            "panel": panel,
            "pct_lbl": pct_lbl,
            "status_lbl": st_lbl,
            "bar_bg": bar_bg,
            "bar_fill": bar_fill,
            "issues_lbl": issues_lbl,
            "details_btn": details_btn,
            "details_handler": None,
            "current_issues": []
        }
        return panel

    # ---------------- Draw Circular Progress ----------------
    def draw_circle_progress(self, panel, percent, color):
        import System.Drawing as sd
        import System.Drawing.Drawing2D as drawing2D
        
        def paint_handler(sender, e):
            g = e.Graphics
            g.SmoothingMode = drawing2D.SmoothingMode.AntiAlias
            rect = sd.Rectangle(10, 10, panel.Width-20, panel.Height-20)
            
            # Draw background circle
            pen_bg = sd.Pen(sd.Color.LightGray, 12)
            g.DrawArc(pen_bg, rect, 0, 360)
            
            # Draw progress arc
            pen_fg = sd.Pen(color, 12)
            sweep = int(360 * (percent / 100.0))
            g.DrawArc(pen_fg, rect, -90, sweep)
            
            # Draw percentage text
            font = sd.Font("Segoe UI", 16, sd.FontStyle.Bold)
            brush = sd.SolidBrush(sd.Color.Black)
            text = "{}%".format(percent)
            sz = g.MeasureString(text, font)
            x = (panel.Width - sz.Width)/2
            y = (panel.Height - sz.Height)/2
            g.DrawString(text, font, brush, x, y)
        
        # Remove previous paint handler if exists
        try:
            panel.Paint -= panel.Paint
        except:
            pass
        
        panel.Paint += paint_handler
        panel.Refresh()

    # ---------------- Show Details Dialog ----------------
    def show_details_dialog(self, title, items):
        details_form = Form()
        details_form.Text = "{} - Details".format(title)
        details_form.Size = Size(600, 420)
        details_form.StartPosition = FormStartPosition.CenterScreen
        details_form.BackColor = Color.White
        
        listbox = ListBox()
        listbox.Location = Point(10, 10)
        listbox.Size = Size(560, 320)
        listbox.Font = Font("Consolas", 9)
        
        if items:
            for item in items:
                listbox.Items.Add(str(item))
        else:
            listbox.Items.Add("No issues found!")
        
        close_btn = Button()
        close_btn.Text = "Close"
        close_btn.Location = Point(250, 340)
        close_btn.Size = Size(100, 30)
        close_btn.Click += lambda s, e: details_form.Close()
        
        details_form.Controls.Add(listbox)
        details_form.Controls.Add(close_btn)
        details_form.ShowDialog()

    # ---------------- Run and update ----------------
    def run_and_update(self):
        try:
            link_res = self.checker.check_revit_links()
            fam_res = self.checker.check_unused_family_symbols()
            vtmpl_res = self.checker.check_view_templates()
            lg_res = self.checker.check_levels_grids_pinned()
            warn_res = self.checker.check_warnings()

            results = {
                "Revit Links": link_res,
                "Unused Families": fam_res,
                "View Templates": vtmpl_res,
                "Levels Pinned": lg_res["levels"],
                "Grids Pinned": lg_res["grids"],
                "Warnings": warn_res
            }

            # Weighted overall
            weights = {
                "Revit Links": 0.20,
                "Unused Families": 0.30,
                "View Templates": 0.30,
                "Levels Pinned": 0.10,
                "Grids Pinned": 0.05,
                "Warnings": 0.05
            }
            total = 0.0
            for k, v in results.items():
                w = weights.get(k, 0.0)
                pct = int(v.get("percent", 100) if isinstance(v, dict) else 100)
                total += pct * w
            overall = int(round(max(0, min(100, total))))
            col, status = get_status_color(overall)

            # Draw circular progress
            self.draw_circle_progress(self.ui["circle_panel"], overall, col)

            # Update category panels
            self.update_category("Revit Links", results["Revit Links"])
            self.update_category("Unused Families", results["Unused Families"])
            self.update_category("View Templates", results["View Templates"])
            self.update_category("Levels Pinned", results["Levels Pinned"])
            self.update_category("Grids Pinned", results["Grids Pinned"])
            self.update_category("Warnings", results["Warnings"], show_count=True)

        except Exception as ex:
            tb = traceback.format_exc()
            try:
                from Autodesk.Revit.UI import TaskDialog
                TaskDialog.Show("Error", str(ex) + "\n\n" + tb)
            except:
                print("Error:", str(ex))
                print(tb)

    def update_category(self, key, data, show_count=False):
        ui = self.ui.get(key)
        if ui is None:
            return
        
        pct = data.get("percent", 100)
        color, status = get_status_color(pct)
        issues = data.get("issues", [])
        
        # Update UI elements
        ui["pct_lbl"].Text = "{}%".format(pct)
        ui["pct_lbl"].ForeColor = color
        ui["status_lbl"].Text = status
        ui["status_lbl"].ForeColor = color
        ui["bar_fill"].Width = int(ui["bar_bg"].Width * pct / 100.0)
        ui["bar_fill"].BackColor = color
        
        if show_count:
            count = data.get("count", 0)
            ui["issues_lbl"].Text = "{} warnings".format(count)
            ui["issues_lbl"].ForeColor = Color.DarkRed if count > 0 else Color.DarkGreen
        else:
            if not issues:
                ui["issues_lbl"].Text = "No issues found"
                ui["issues_lbl"].ForeColor = Color.DarkGreen
            else:
                ui["issues_lbl"].Text = "{} issues found".format(len(issues))
                ui["issues_lbl"].ForeColor = Color.DarkRed
        
        # Store current issues for details button
        ui["current_issues"] = issues
        
        # Remove previous click handler if exists
        try:
            ui["details_btn"].Click -= ui["details_handler"]
        except:
            pass
        
        # Create new click handler
        def details_handler(sender, event):
            self.show_details_dialog(key, ui["current_issues"])
        
        ui["details_handler"] = details_handler
        ui["details_btn"].Click += ui["details_handler"]

# ---------------- Main ----------------
try:
    doc = __revit__.ActiveUIDocument.Document
    form = HealthDashboard(doc)
    form.ShowDialog()
except Exception as e:
    try:
        from Autodesk.Revit.UI import TaskDialog
        TaskDialog.Show("Error", "Failed to initialize dashboard: {}".format(str(e)))
    except:
        print("Failed to initialize dashboard:", str(e))
        traceback.print_exc()