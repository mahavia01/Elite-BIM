from Autodesk.Revit.DB import *
from pyrevit import revit, DB, script
import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitServices')

from pyrevit import revit, forms, script
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI.Selection import ObjectType

doc = revit.doc
uidoc = revit.uidoc

Created_Schedule_Name = "ELEMENTS WITH MISSING PARAMETERS"

schedule_names = [s.Name for s in FilteredElementCollector(doc).OfClass(ViewSchedule).ToElements()]
if Created_Schedule_Name in schedule_names:
    forms.alert("Schedule 'ELEMENTS WITH MISSING PARAMETERS' Already Exists.\nDelete or Rename Existing Schedule To Continue...")
    script.exit()

Parameter_To_Check = [
    "(01)QIC_ABS_L1_DISTRICT_CODE", "(02)QIC_ABS_L1_PROJECT_CODE", "(03)QIC_ABS_L2_ZONE_CODE", 
    "(04)QIC_ABS_L2_BUILDING_CODE", "(05)QIC_ABS_L2_LEVEL _CODE", "(06)QIC_ABS_L2_ROOM_UNIQUE_NUMBER"
]

forms.alert("Select Elements To Check Parameters", warn_icon=False)
try:
    selected_refs = uidoc.Selection.PickObjects(ObjectType.Element, "Select Elements to Check Parameters")
except:
    forms.alert("Selection cancelled. Exiting.")
    script.exit()

selected_elements = [doc.GetElement(ref) for ref in selected_refs]
elements_with_empty_params = {}
missing_params_set = set()


for el in selected_elements:
    missing_params = []
    for param_name in Parameter_To_Check:
        param = el.LookupParameter(param_name)
        if param:
            value = param.AsString() if param.StorageType == StorageType.String else param.AsValueString()
            if not value:
                missing_params.append(param_name)
                missing_params_set.add(param_name)
        else:
            missing_params.append(param_name)
            missing_params_set.add(param_name)
    if missing_params:
        elements_with_empty_params[el.Id] = missing_params

if not elements_with_empty_params:
    forms.alert("All Parameters Are Filled In Selected Elements!", warn_icon=False)
    script.exit()

with Transaction(doc, "Add Value to 'Missing Parameters'") as t:
    t.Start()
    for el_id in elements_with_empty_params:
        el = doc.GetElement(el_id)
        param = el.LookupParameter("QC_Tag")
        if not param:
            forms.alert("Parameter 'QC_Tag' Not Found\nCreate Parameter to Continue...")
            script.exit()
        else:
            if param and param.StorageType == StorageType.String:
                param.Set("Missing Parameters")
    t.Commit()

missing_shared_parameters = []

for el in selected_elements:
    for param_name in Parameter_To_Check:
        para = el.LookupParameter(param_name)
        if not para:
            if param_name not in missing_shared_parameters:
                missing_shared_parameters.append(param_name)

if missing_shared_parameters:
    forms.alert("Can Not Run Parameter Check Because Below Listed parameters are missing from elements:\n{}".format("\n".join(missing_shared_parameters)))
    script.exit()

with Transaction(doc, "Create Schedule") as t:
    t.Start()
    schedule = ViewSchedule.CreateSchedule(doc, ElementId.InvalidElementId)
    schedule.Name = Created_Schedule_Name
    sched_def = schedule.Definition

    sched_def.AddField(ScheduleFieldType.Instance, ElementId(BuiltInParameter.ELEM_FAMILY_PARAM))
    sched_def.AddField(ScheduleFieldType.Instance, ElementId(BuiltInParameter.ELEM_TYPE_PARAM))
    
    first_el = doc.GetElement(list(elements_with_empty_params.keys())[0])
    custom_param = first_el.LookupParameter("QC_Tag")
    if not custom_param:
        forms.alert("Parameter 'QC_Tag' not found.\nCreate Parameter To Continue...", warn_icon=True)
        script.exit()
    
    param_ids_added = []
    for param_name in missing_params_set:
        param = first_el.LookupParameter(param_name)
        if param:
            param_ids_added.append(param.Id)
            sched_def.AddField(ScheduleFieldType.Instance, param.Id)
        else:
            param_elem = None
            for param in doc.ParameterBindings:
                if param.Name == param_name:
                    param_elem = param
                    break
            if param_elem:
                param_ids_added.append(param_elem.Id)
                sched_def.AddField(ScheduleFieldType.Instance, param_elem.Id)
    
    qc_tag_field = sched_def.AddField(ScheduleFieldType.Instance, custom_param.Id)
    schedule_filter = ScheduleFilter(qc_tag_field.FieldId, ScheduleFilterType.Equal, "Missing Parameters")
    sched_def.AddFilter(schedule_filter)
    
    t.Commit()


def hide_schedule_column(schedule, parameter_name_to_hide):
    sched_def = schedule.Definition
    fields = [sched_def.GetField(i) for i in range(sched_def.GetFieldCount())]
    parameter_name_to_hide = "QC_Tag"
    for field in fields:
        param = doc.GetElement(field.ParameterId)
        if param and param.Name == parameter_name_to_hide:
            with Transaction(doc, "Hide Schedule Column") as t:
                t.Start()
                field.IsHidden = True
                t.Commit()
            return True
    return False
coyrright_symbole = u"\u00A9"
forms.alert(
    "".join([
        "Schedule created successfully!\n",
        "Schedule name: 'ELEMENTS WITH MISSING PARAMETERS'.\n",
        u"\u00A9", 
        "by muhammad mahavia.\nEnjoy!!!"
    ]),
    title="Done, Schedule Created", 
    warn_icon=False
)