import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitServices')
from Autodesk.Revit.DB import *
from pyrevit import revit, forms, script


doc = revit.doc

# For Checking Schedules
required_Schedules = [
    "QIC_BIM_USES",
    "QIC_MULTI-CATEGORY SCHEDULE",
    "QIC_ASSET_INFORMATION",
    "QIC_4D & 5D INFORMATION",
    "QIC MODEL ISSUE DATA LOG"
]

schedules = FilteredElementCollector(doc).OfClass(ViewSchedule).ToElements()
schedule_names = [s.Name for s in schedules]

missing = []
for s in required_Schedules:
    if not any(s in name for name in schedule_names):
        missing.append(s)

if not missing:
    forms.alert("All Required Schedules Are Existing In The Model!", title="Schedule Check")
else:
    message = "The Following Schedules Are Missing In Current Model:\n\n"
    message += "\n".join(missing)
    forms.alert(message, title="Missing Schedule Names", warn_icon=True)

