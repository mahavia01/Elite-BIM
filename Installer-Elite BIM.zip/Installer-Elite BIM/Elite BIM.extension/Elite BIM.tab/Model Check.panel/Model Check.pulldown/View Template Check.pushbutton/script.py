from Autodesk.Revit.DB import *
from pyrevit import revit, forms

doc = revit.doc

views_missing_templates = []
all_sheets = FilteredElementCollector(doc).OfClass(ViewSheet).ToElements()

for sheet in all_sheets:
    for view_id in sheet.GetAllPlacedViews():
        view = doc.GetElement(view_id)
        if view and view.ViewType not in [ViewType.DrawingSheet, 
                                        ViewType.Legend,
                                        ViewType.DraftingView]:
            
            if view and not view.IsTemplate:
                 if not view.ViewTemplateId or view.ViewTemplateId == ElementId.InvalidElementId:
                     views_missing_templates.append(view.Name)

if views_missing_templates:
    message = "Missing View Template In Below Views:\n" + "\n ".join(views_missing_templates)
    forms.alert(message, 
               title="Missing View Templates", 
               warn_icon=True)
else:
    forms.alert("All sheet views have view templates assigned", 
               title="Template Check Complete", 
               warn_icon=False)