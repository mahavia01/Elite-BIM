import clr
clr.AddReference("RevitServices")
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")
clr.AddReference("System")

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
from pyrevit import forms, script, revit
from System.Collections.Generic import List

doc = revit.doc
uidoc = revit.uidoc


slope_list = {"0.5": 0.5, "1%": 1.0, "1.5%": 1.5, "2%": 2.0, "2.5%": 2.5, "3%": 3.0}
all_slope_values = list(slope_list.values())


selected_refs = uidoc.Selection.PickObjects(ObjectType.Element, "Select pipes to check slope")
selected_elements = [doc.GetElement(ref) for ref in selected_refs]


selected_pipes = []
for elem in selected_elements:
    if elem.Category is not None and elem.Category.Id.IntegerValue == int(BuiltInCategory.OST_PipeCurves):
        selected_pipes.append(elem)


pipes_without_matching_slope = []
pipes_with_matching_slope = []

for pipe in selected_pipes:
    slope_param = pipe.get_Parameter(BuiltInParameter.RBS_PIPE_SLOPE)
    
    if slope_param and slope_param.HasValue:
        pipe_slope = slope_param.AsDouble()
        
        has_matching_slope = False
        for target_slope in all_slope_values:
            if abs(pipe_slope - target_slope) < 0.0001:
                has_matching_slope = True
                break
        
        if has_matching_slope:
            pipes_with_matching_slope.append(pipe)
        else:
            pipes_without_matching_slope.append(pipe)
    else:
        pipes_without_matching_slope.append(pipe)


print("Total selected pipes: {}".format(len(selected_pipes)))
print("Pipes with matching slope: {}".format(len(pipes_with_matching_slope)))
print("Pipes without matching slope: {}".format(len(pipes_without_matching_slope)))

if pipes_without_matching_slope:
    try:
        with revit.Transaction("Isolate Wrong Slope Pipes"):
            current_view = doc.ActiveView
            element_ids = List[ElementId]([pipe.Id for pipe in pipes_without_matching_slope])
            current_view.IsolateElementsTemporary(element_ids)
        
        print("Isolated {} pipes without matching slope".format(len(pipes_without_matching_slope)))
        
        # Show detailed information
        print("\n=== PIPES WITHOUT MATCHING SLOPE ===")
        for i, pipe in enumerate(pipes_without_matching_slope):
            slope_param = pipe.get_Parameter(BuiltInParameter.RBS_PIPE_SLOPE)
            if slope_param and slope_param.HasValue:
                slope_value = slope_param.AsDouble()
                print("{}. Pipe ID: {} | Slope: {:.6f}%".format(i+1, pipe.Id.IntegerValue, slope_value))
            else:
                print("{}. Pipe ID: {} | Slope: No slope value".format(i+1, pipe.Id.IntegerValue))
                
        forms.alert("Isolated {} pipes without matching slope".format(len(pipes_without_matching_slope)))
        
    except Exception as e:
        forms.alert("Error isolating pipes: " + str(e))
        print("Error: " + str(e))
else:
    print("All selected pipes have matching slopes!")
    forms.alert("All {} selected pipes have matching slopes!".format(len(selected_pipes)))