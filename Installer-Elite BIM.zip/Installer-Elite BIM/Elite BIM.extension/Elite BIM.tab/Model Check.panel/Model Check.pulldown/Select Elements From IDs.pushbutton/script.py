from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from pyrevit import forms
import clr
import System
from System.Collections.Generic import List

clr.AddReferenceByName('Microsoft.Office.Interop.Excel, Version=15.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c')
from Microsoft.Office.Interop import Excel

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

try:
    excel_path = forms.pick_file(file_ext='xlsx', title='Select Excel File with Element IDs')
    if not excel_path:
        forms.alert("No file selected. Exiting.", exitscript=True)
except:
    forms.alert("File selection failed.", exitscript=True)

element_ids = []
excel_app = None

try:
    excel_app = Excel.ApplicationClass()
    workbook = excel_app.Workbooks.Open(excel_path)
    worksheet = workbook.Sheets[1]
    i = 1
    while i <= 10000: 
        cell_value = worksheet.Range["A{}".format(i)].Value2
        if cell_value is None:
            break 
        
        try:
            element_ids.append(int(float(cell_value)))
        except:
            pass
        i += 1
except Exception as e:
    forms.alert("Excel Error:\n{}".format(str(e)), exitscript=True)

finally:
    if 'workbook' in locals():
        workbook.Close(False)
    if excel_app:
        excel_app.Quit()
        System.Runtime.InteropServices.Marshal.ReleaseComObject(excel_app)
if not element_ids:
    forms.alert("No valid Element IDs found.", exitscript=True)

success_ids = []
failed_ids = []

for element_id in element_ids:
    try:
        element = doc.GetElement(ElementId(element_id))
        if element:
            success_ids.append(element.Id)
        else:
            failed_ids.append(str(element_id))
    except:
        failed_ids.append(str(element_id))
if success_ids:
    uidoc.Selection.SetElementIds(List[ElementId](success_ids))
    msg = "Selected {} elements".format(len(success_ids))
    if failed_ids:
        msg += "\n\nFailed IDs:\n" + ", ".join(failed_ids[:20])
        if len(failed_ids) > 20:
            msg += "\n...and {} more".format(len(failed_ids)-20)
    forms.alert(msg)
else:
    forms.alert("No valid elements found.", exitscript=True)