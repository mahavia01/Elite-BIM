import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitServices")
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from pyrevit import revit, script

doc = revit.doc

Generic_Models = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_GenericModel).WhereElementIsNotElementType().ToElements()

if Generic_Models:
    # Show number of Generic Models found
    Button = TaskDialog.Show("Message", "Number Of Generic Models detected: {}\nDelete now?".format(len(Generic_Models)), TaskDialogCommonButtons.Yes | TaskDialogCommonButtons.No)

    if Button == TaskDialogResult.Yes:
        t = Transaction(doc, "Delete Generic Models")
        t.Start()
        for model in Generic_Models:      
            doc.Delete(model.Id)
        t.Commit()

        if Button == TaskDialogResult.No:
            script.exit()
else:
    TaskDialog.Show("Message", "No Generic Models Found In The Model")

# This script is Designed and Developed by Muhammad Mahavia 