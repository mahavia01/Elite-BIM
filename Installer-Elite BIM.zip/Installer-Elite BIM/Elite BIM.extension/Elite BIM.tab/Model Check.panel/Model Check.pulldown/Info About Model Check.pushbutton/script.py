from pyrevit import forms, script

forms.alert("Model Check Tool is fully customized for specific project requirements. For example, the parameter check will only validate parameters defined for specific project.To use this tool based on your own project requirements and specifications, you can customize the script file located in your directory.\nFor any Help contact: m.mahavia01@gmail.com", warn_icon = False)
script.exit()