from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from pyrevit import revit, forms, script

doc = revit.doc 

all_publish_sets = FilteredElementCollector(doc).OfClass(ViewSheetSet).ToElements()

required_publish_set_name = "CONSTRUCTION DOCUMENTS LOD-400"

if required_publish_set_name in all_publish_sets:
    forms.alert("Required Publish Set Are Available.")
    script.exit()
else:
    forms.alert("Missing Publish Set.\nName: CONSTRUCTIOIN DOCUMNETS LOD-400")
    script.exit()
