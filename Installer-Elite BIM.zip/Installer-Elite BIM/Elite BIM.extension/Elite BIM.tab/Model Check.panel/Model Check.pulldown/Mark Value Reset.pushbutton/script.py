from pyrevit import script, forms
from Autodesk.Revit.DB import FilteredElementCollector, Transaction

doc = __revit__.ActiveUIDocument.Document

# Collect all elements with Mark = "Missing Parameters"
elements_to_clear = []

all_elements = FilteredElementCollector(doc).WhereElementIsNotElementType().ToElements()

for element in all_elements:
    param = element.LookupParameter("Mark")
    if param and param.HasValue and param.AsString() == "Missing Parameters":
        elements_to_clear.append(param)

# Act based on results
if not elements_to_clear:
    forms.alert("No affected 'Mark' values found.", warn_icon=False)
    script.exit()

# Clear values inside a transaction
with Transaction(doc, "Clear Mark Parameters") as t:
    t.Start()
    for param in elements_to_clear:
        param.Set("")
    t.Commit()

forms.alert("All 'Mark' values have been cleared.", warn_icon=False)
