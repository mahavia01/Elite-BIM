from Autodesk.Revit.DB import *
from pyrevit import revit, script, forms

doc = revit.doc

all_elements = FilteredElementCollector(doc).WhereElementIsNotElementType().ToElements()
parameter_exists = False
any_value_cleared = False

with Transaction(doc, "Clear QC_Tag Values") as t:
    t.Start()
    for ele in all_elements:
        parameter = ele.LookupParameter("QC_Tag")
        if parameter:
            parameter_exists = True
            if not parameter.IsReadOnly:
                try:
                    parameter.Set("")
                    any_value_cleared = True
                except:
                    pass
    
    t.Commit()
if parameter_exists:
    forms.alert("All QC_Tag parameter values have been cleared", 
               title="Success")
else:
    forms.alert("QC_Tag parameter not found in model", 
               title="Parameter Missing", 
               warn_icon=True)