from Autodesk.Revit.DB import *
from pyrevit import revit, forms

doc = revit.doc

views_with_text = []
all_sheets = FilteredElementCollector(doc).OfClass(ViewSheet).ToElements()

for sheet in all_sheets:
    for view_id in sheet.GetAllPlacedViews():
        view = doc.GetElement(view_id)
        if view and view.ViewType not in [ViewType.DrawingSheet, 
                                        ViewType.Legend,
                                        ViewType.DraftingView]:
            text_notes = FilteredElementCollector(doc, view.Id)\
                        .OfCategory(BuiltInCategory.OST_TextNotes)\
                        .WhereElementIsNotElementType()\
                        .ToElements()
            
            if text_notes:
                views_with_text.append(view.Name)
if views_with_text:
    message = "Text notes found in:\n\n " + "\n ".join(views_with_text)
    forms.alert(message, 
               title="Text Notes Found", 
               warn_icon=False)
else:
    forms.alert("No text notes found in sheet views", 
               warn_icon=False)