from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from pyrevit import revit, forms
from System.Collections.Generic import List
from Autodesk.Revit.UI.Selection import *

doc = revit.doc
uidoc = revit.uidoc

current_view = doc.ActiveView
if not isinstance(current_view, ViewPlan):
    forms.alert("This tool only works in floor plan views.", exitscript=True)

current_level_name = current_view.GenLevel.Name

try:
    selection = uidoc.Selection.PickObjects(ObjectType.Element, "Select elements")
    selected_elements = [doc.GetElement(el) for el in selection]
except:
    forms.alert("Selection cancelled.", exitscript=True)

elements_with_wrong_level = []

for ele in selected_elements:
    ref_level_param = ele.LookupParameter("Reference Level")
    if ref_level_param:
        element_level_name = ref_level_param.AsValueString()
        if element_level_name != current_level_name:
            elements_with_wrong_level.append(ele)

if elements_with_wrong_level:
    with Transaction(doc, "Isolate Wrong Level Elements") as t:
        t.Start()
        element_ids = List[ElementId]([e.Id for e in elements_with_wrong_level])
        current_view.IsolateElementsTemporary(element_ids)
        t.Commit()
        forms.alert("All Elements With Incorrect Level has been Isolated.")
else:
    forms.alert(
        "All elements match current level: {}".format(current_level_name),
        title="Level Check Complete"
    )