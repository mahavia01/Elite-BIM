import webbrowser



url = "github.com/mahavia01"


webbrowser.open(url)
