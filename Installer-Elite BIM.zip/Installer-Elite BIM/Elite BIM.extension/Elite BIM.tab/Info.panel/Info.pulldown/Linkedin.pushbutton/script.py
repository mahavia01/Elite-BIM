import webbrowser



url = "https://www.linkedin.com/in/muhammadmahavia?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=ios_app"


webbrowser.open(url)
