🛠️ Elite BIM Tool – Installer Guide
────────────────────────────────────────

📌 Description:
This tool adds custom Elite BIM TAB into your Revit interface.

✅ Requirements:
- Revit (any version compatible with pyRevit)
- pyRevit must be installed first  
  You can download it from: https://www.pyrevitlabs.io

📥 Installation Steps:
1. Make sure pyRevit is installed and working with Revit.
2. Extract the contents of this ZIP file anywhere on your computer.
3. Right-click on `install.bat` and choose **Run as Administrator**.
4. The tool will automatically copy the "Elite_BIM.extension" folder to your pyRevit extensions directory:
   `%APPDATA%\pyRevit-Master\extensions`
5. Restart Revit.
6. You will now see the **Elite BIM** tab in Revit.

💡 Notes:
- If Revit is open, close and reopen it after installation.
- If you update the tool, simply run `install.bat` again.

📞 Support:
For questions or updates, contact:
Email: m.mahavia01@gmail.com

────────────────────────────────────────
🚀 Thank you for using Elite BIM Tool!
